<?php
/**
 * Initieringsfil för BRF Beryllen's intranät
 * 
 * Denna fil initierar grundläggande inställningar och klasser
 * för hela systemet. Den bör inkluderas i början av varje sida.
 */

// Starta sessionshantering om den inte redan är startad
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Definiera konstanter för filsökvägar
define('ROOT_PATH', realpath(dirname(__FILE__)));
define('INCLUDES_PATH', ROOT_PATH . '/includes');
define('CLASSES_PATH', INCLUDES_PATH . '/classes');
define('CONFIG_PATH', ROOT_PATH . '/config');
define('UPLOADS_PATH', ROOT_PATH . '/uploads');
define('TEMPLATES_PATH', ROOT_PATH . '/templates');
define('LOGS_PATH', ROOT_PATH . '/logs');

// Definiera ACCESS_ALLOWED för att förhindra direkt åtkomst till vissa filer
define('ACCESS_ALLOWED', true);

// Inkludera konfigurationsfiler
require_once(CONFIG_PATH . '/config.php');
require_once(CONFIG_PATH . '/database.php');

// Säkerställ att loggmappen finns och är skrivbar
if (!file_exists(LOGS_PATH)) {
    mkdir(LOGS_PATH, 0755, true);
}

// Sätt upp felhantering
error_reporting(E_ALL);
ini_set('display_errors', 1); // Sätt till 1 under utveckling, 0 i produktion
ini_set('log_errors', 1);
ini_set('error_log', LOGS_PATH . '/error.log');

// Autoload-funktion för klasser
function autoloadClasses($className) {
    $classFile = CLASSES_PATH . '/' . $className . '.php';
    if (file_exists($classFile)) {
        require_once($classFile);
    }
}
spl_autoload_register('autoloadClasses');

// Hjälpfunktioner
require_once(INCLUDES_PATH . '/functions.php');

// Skapa instanser av grundläggande klasser
$db = Database::getInstance(); // Databasanslutning
$auth = new Auth(); // Autentisering

// Hämta webbplatsens inställningar från databasen
function getSiteSettings() {
    $db = Database::getInstance();
    $settings = [];
    
    $siteSettings = $db->getRows("SELECT * FROM config WHERE category = 'site'");
    if ($siteSettings) {
        foreach ($siteSettings as $setting) {
            $settings[$setting['name']] = $setting['value'];
        }
    }
    
    return $settings;
}

// Hjälpfunktion för att generera CSRF-token
function generateCSRFToken() {
    if (!isset($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

// Hjälpfunktion för att validera CSRF-token
function validateCSRFToken($token) {
    if (!isset($_SESSION['csrf_token']) || $token !== $_SESSION['csrf_token']) {
        return false;
    }
    return true;
}

// Hämta globala inställningar
$siteSettings = getSiteSettings();