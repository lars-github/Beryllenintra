<?php
/**
 * Hantering av parkeringsköer för BRF Beryllen
 * 
 * Denna sida låter administratörer hantera kösystem för parkeringsplatser
 */

// Initiera systemet
require_once('../init.php');

// Kontrollera att användaren är inloggad och har admin-rättigheter
if (!$auth->isLoggedIn() || !($auth->hasRole('admin') || $auth->hasRole('superadmin'))) {
    $_SESSION['flash_message'] = 'Du har inte behörighet att visa denna sida.';
    $_SESSION['flash_type'] = 'warning';
    redirect(SITE_URL . '/index.php');
}

// Hjälpfunktion för att översätta platstyper
function getSpotTypeText($type) {
    switch ($type) {
        case 'outdoor':
            return 'Utomhusplats';
        case 'garage':
            return 'Garageplats';
        case 'garage_large':
            return 'Stor garageplats';
        case 'garage_separate':
            return 'Separat garage';
        case 'motorcycle':
            return 'MC-plats';
        case 'any':
            return 'Alla typer';
        default:
            return $type;
    }
}

// Hjälpfunktion för att logga aktivitet
function logActivity($userId, $action, $entityType, $entityId, $description) {
    $db = Database::getInstance();
    $ipAddress = $_SERVER['REMOTE_ADDR'] ?? null;
    
    $db->execute(
        "INSERT INTO activity_logs (user_id, action, entity_type, entity_id, description, ip_address) 
         VALUES (?, ?, ?, ?, ?, ?)",
        [$userId, $action, $entityType, $entityId, $description, $ipAddress]
    );
}

// Ladda Users-klassen
require_once('../includes/classes/Users.php');
$userManager = new UserManager();

// Hantera ändring av kötillägg
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_to_queue'])) {
    // Validera CSRF-token
    if (!validateCSRFToken($_POST['csrf_token'] ?? '')) {
        $_SESSION['flash_message'] = 'Ogiltigt formulär. Försök igen.';
        $_SESSION['flash_type'] = 'danger';
    } else {
        $userId = (int)$_POST['user_id'];
        $queueTypeId = (int)$_POST['queue_type_id'];
        
        // Kontrollera om användaren redan står i kö
        $db = Database::getInstance();
        $existingQueue = $db->getRow(
            "SELECT * FROM parking_queue WHERE user_id = ? AND queue_type_id = ? AND status = 'active'", 
            [$userId, $queueTypeId]
        );
        
        if ($existingQueue) {
            $_SESSION['flash_message'] = 'Användaren står redan i denna kö.';
            $_SESSION['flash_type'] = 'warning';
        } else {
            // Beräkna ny position (sist i kön)
            $positionResult = $db->getRow(
                "SELECT COUNT(*) as count FROM parking_queue WHERE queue_type_id = ? AND status = 'active'", 
                [$queueTypeId]
            );
            $position = $positionResult['count'];
            
            // Lägg till användaren i kön
            $success = $db->execute(
                "INSERT INTO parking_queue (user_id, queue_type_id, position, status) VALUES (?, ?, ?, 'active')",
                [$userId, $queueTypeId, $position]
            );
            
            if ($success !== false) {
                // Logga aktivitet
                $insertId = $db->getLastInsertId();
                logActivity($userId, 'create', 'parking_queue', $insertId, 'Användare tillagd i parkeringskö');
                
                $_SESSION['flash_message'] = 'Användaren har lagts till i kön.';
                $_SESSION['flash_type'] = 'success';
            } else {
                $_SESSION['flash_message'] = 'Kunde inte lägga till användaren i kön. Försök igen.';
                $_SESSION['flash_type'] = 'danger';
            }
        }
    }
    
    redirect(SITE_URL . '/admin/parking_queue_management.php');
}

// Hantera direkt tilldelning av parkeringsplats från köer
if (isset($_GET['action']) && $_GET['action'] == 'assign_spot' && isset($_GET['queue_id']) && isset($_GET['spot_id'])) {
    $queueId = (int)$_GET['queue_id'];
    $spotId = (int)$_GET['spot_id'];
    $startDate = $_GET['start_date'] ?? date('Y-m-d');
    
    $db = Database::getInstance();
    
    // Hämta användarinformation från kön
    $queueInfo = $db->getRow(
        "SELECT user_id, queue_type_id, position FROM parking_queue WHERE queue_id = ?",
        [$queueId]
    );
    
    if (!$queueInfo) {
        $_SESSION['flash_message'] = 'Kunde inte hitta köposten.';
        $_SESSION['flash_type'] = 'danger';
        redirect(SITE_URL . '/admin/parking_queue_management.php');
    }
    
    $userId = $queueInfo['user_id'];
    
    // Kontrollera att platsen är tillgänglig
    $spotResult = $db->getRow(
        "SELECT is_available FROM parking_spots WHERE spot_id = ?", 
        [$spotId]
    );
    $spotAvailable = isset($spotResult['is_available']) ? $spotResult['is_available'] : 0;
    
    if (!$spotAvailable) {
        $_SESSION['flash_message'] = 'Parkeringsplatsen är inte tillgänglig.';
        $_SESSION['flash_type'] = 'danger';
    } else {
        // Skapa de frågor som ska köras i transaktionen
        $queries = [
            // 1. Uppdatera status för parkeringsplatsen
            [
                'query' => "UPDATE parking_spots SET is_available = 0 WHERE spot_id = ?",
                'params' => [$spotId]
            ],
            // 2. Skapa en ny tilldelning
            [
                'query' => "INSERT INTO parking_assignments (spot_id, user_id, start_date, status) VALUES (?, ?, ?, 'active')",
                'params' => [$spotId, $userId, $startDate]
            ],
            // 3. Uppdatera kö-status till 'inaktiv'
            [
                'query' => "UPDATE parking_queue SET status = 'inactive' WHERE queue_id = ?",
                'params' => [$queueId]
            ],
            // 4. Uppdatera positioner för alla andra i kön
            [
                'query' => "UPDATE parking_queue 
                           SET position = position - 1 
                           WHERE queue_type_id = ? 
                           AND position > ? 
                           AND status = 'active'",
                'params' => [$queueInfo['queue_type_id'], $queueInfo['position']]
            ]
        ];
        
        // Kör transaktionen
        $result = $db->transaction($queries);
        
        if ($result) {
            // Logga aktivitet
            $insertId = $db->getLastInsertId();
            logActivity($userId, 'create', 'parking_assignment', $insertId, 'Parkeringsplats tilldelad');
            
            $_SESSION['flash_message'] = 'Parkeringsplats har tilldelats användaren.';
            $_SESSION['flash_type'] = 'success';
        } else {
            $_SESSION['flash_message'] = 'Ett fel uppstod vid tilldelning av parkeringsplats.';
            $_SESSION['flash_type'] = 'danger';
        }
    }
    
    redirect(SITE_URL . '/admin/parking_queue_management.php');
}

// Hantera avslut av parkeringstilldelning
if (isset($_GET['action']) && $_GET['action'] == 'end_assignment' && isset($_GET['assignment_id'])) {
    $assignmentId = (int)$_GET['assignment_id'];
    $endDate = $_GET['end_date'] ?? date('Y-m-d');
    
    $db = Database::getInstance();
    
    // Hämta information om tilldelningen
    $assignment = $db->getRow(
        "SELECT spot_id, user_id FROM parking_assignments WHERE assignment_id = ?",
        [$assignmentId]
    );
    
    if (!$assignment) {
        $_SESSION['flash_message'] = 'Kunde inte hitta tilldelningen.';
        $_SESSION['flash_type'] = 'danger';
    } else {
        // Skapa frågor för transaktionen
        $queries = [
            // 1. Uppdatera tilldelningens status och slutdatum
            [
                'query' => "UPDATE parking_assignments SET status = 'terminated', end_date = ? WHERE assignment_id = ?",
                'params' => [$endDate, $assignmentId]
            ],
            // 2. Markera parkeringsplatsen som tillgänglig igen
            [
                'query' => "UPDATE parking_spots SET is_available = 1 WHERE spot_id = ?",
                'params' => [$assignment['spot_id']]
            ]
        ];
        
        // Kör transaktionen
        $result = $db->transaction($queries);
        
        if ($result) {
            // Logga aktivitet
            logActivity($assignment['user_id'], 'update', 'parking_assignment', $assignmentId, 'Parkeringstilldelning avslutad');
            
            $_SESSION['flash_message'] = 'Parkeringstilldelning har avslutats.';
            $_SESSION['flash_type'] = 'success';
        } else {
            $_SESSION['flash_message'] = 'Ett fel uppstod vid avslutning av parkeringstilldelning.';
            $_SESSION['flash_type'] = 'danger';
        }
    }
    
    redirect(SITE_URL . '/admin/parking_queue_management.php');
}

// Hantera borttagning från kö
if (isset($_GET['action']) && $_GET['action'] == 'remove_from_queue' && isset($_GET['id'])) {
    $queueId = (int)$_GET['id'];
    
    $db = Database::getInstance();
    
    // Hämta information om köposition
    $queueInfo = $db->getRow(
        "SELECT user_id, queue_type_id, position FROM parking_queue WHERE queue_id = ?",
        [$queueId]
    );
    
    if (!$queueInfo) {
        $_SESSION['flash_message'] = 'Kunde inte hitta köposten.';
        $_SESSION['flash_type'] = 'danger';
    } else {
        // Skapa frågor för transaktionen
        $queries = [
            // 1. Ta bort från kön
            [
                'query' => "UPDATE parking_queue SET status = 'inactive' WHERE queue_id = ?",
                'params' => [$queueId]
            ],
            // 2. Uppdatera positioner för alla andra i kön
            [
                'query' => "UPDATE parking_queue 
                           SET position = position - 1 
                           WHERE queue_type_id = ? 
                           AND position > ? 
                           AND status = 'active'",
                'params' => [$queueInfo['queue_type_id'], $queueInfo['position']]
            ]
        ];
        
        // Kör transaktionen
        $result = $db->transaction($queries);
        
        if ($result) {
            // Logga aktivitet
            logActivity($queueInfo['user_id'], 'update', 'parking_queue', $queueId, 'Användare borttagen från parkeringskö');
            
            $_SESSION['flash_message'] = 'Användaren har tagits bort från kön.';
            $_SESSION['flash_type'] = 'success';
        } else {
            $_SESSION['flash_message'] = 'Ett fel uppstod vid borttagning från parkeringskö.';
            $_SESSION['flash_type'] = 'danger';
        }
    }
    
    redirect(SITE_URL . '/admin/parking_queue_management.php');
}

// Visa tilldelningsidan om vi har queue_id och behöver välja plats
$showAssignForm = false;
$selectedQueue = null;
$spotTypeFilter = null;

if (isset($_GET['action']) && $_GET['action'] == 'assign' && isset($_GET['id'])) {
    $queueId = (int)$_GET['id'];
    $db = Database::getInstance();
    
    // Hämta information om kön
    $selectedQueue = $db->getRow(
        "SELECT pq.*, u.first_name, u.last_name, qt.name as queue_name, qt.spot_type
         FROM parking_queue pq
         JOIN users u ON pq.user_id = u.user_id
         JOIN queue_types qt ON pq.queue_type_id = qt.queue_type_id
         WHERE pq.queue_id = ? AND pq.status = 'active'",
        [$queueId]
    );
    
    if ($selectedQueue) {
        $showAssignForm = true;
        $spotTypeFilter = $selectedQueue['spot_type'];
    }
}

// Hämta alla kötyper
$db = Database::getInstance();
$queueTypes = $db->getRows("SELECT * FROM queue_types WHERE is_active = 1 ORDER BY name");

// Hämta aktiva köer med användar- och kötype-information
$activeQueues = $db->getRows(
    "SELECT pq.*, u.first_name, u.last_name, u.email, qt.name as queue_name, qt.spot_type
     FROM parking_queue pq
     JOIN users u ON pq.user_id = u.user_id
     JOIN queue_types qt ON pq.queue_type_id = qt.queue_type_id
     WHERE pq.status = 'active'
     ORDER BY qt.name, pq.position"
);

// Hämta tillgängliga parkeringsplatser
$availableSpots = $db->getRows(
    "SELECT * FROM parking_spots 
     WHERE is_available = 1 
     ORDER BY type, name"
);

// Om vi har en spotTypeFilter, filtrera platser
$filteredSpots = $availableSpots;
if ($spotTypeFilter && $spotTypeFilter !== 'any') {
    $filteredSpots = array_filter($availableSpots, function($spot) use ($spotTypeFilter) {
        return $spot['type'] === $spotTypeFilter;
    });
}

// Hämta aktiva parkeringstilldelningar
$activeAssignments = $db->getRows(
    "SELECT pa.*, u.first_name, u.last_name, u.email, ps.name as spot_name, ps.type, ps.location
     FROM parking_assignments pa
     JOIN users u ON pa.user_id = u.user_id
     JOIN parking_spots ps ON pa.spot_id = ps.spot_id
     WHERE pa.status = 'active'
     ORDER BY ps.type, ps.name"
);

// Hämta alla användare för dropdown
$users = $userManager->getUsers('active');

// Sidspecifika inställningar
$pageTitle = 'Hantera parkeringsköer';
$pageDescription = 'Administrera parkeringsköer och tilldelningar';

// Inkludera sidhuvud
include(TEMPLATES_PATH . '/header.php');
?>

<div class="container py-4">
    <?php if (isset($_SESSION['debug_info'])): ?>
    <div class="alert alert-info">
        <h5>Debug information:</h5>
        <pre><?php print_r($_SESSION['debug_info']); ?></pre>
    </div>
    <?php unset($_SESSION['debug_info']); endif; ?>

    <div class="row mb-4">
        <div class="col-12">
            <h1>Hantera parkeringsköer</h1>
            <p class="lead">Hantera köer och tilldelningar av parkeringsplatser</p>
        </div>
    </div>

    <?php if ($showAssignForm): ?>
    <!-- Tilldelning av parkeringsplats formulär -->
    <div class="row mb-4">
        <div class="col-12">
            <div class="card shadow-sm">
                <div class="card-header bg-primary text-white">
                    <h5 class="card-title mb-0">Tilldela parkeringsplats till <?php echo $selectedQueue['first_name'] . ' ' . $selectedQueue['last_name']; ?></h5>
                </div>
                <div class="card-body">
                    <form method="get" action="">
                        <input type="hidden" name="action" value="assign_spot">
                        <input type="hidden" name="queue_id" value="<?php echo $selectedQueue['queue_id']; ?>">
                        
                        <div class="row">
                            <div class="col-md-5">
                                <div class="mb-3">
                                    <label for="spot_id" class="form-label">Välj parkeringsplats:</label>
                                    <select name="spot_id" id="spot_id" class="form-select" required>
                                        <option value="">Välj plats...</option>
                                        <?php foreach ($filteredSpots as $spot): ?>
                                        <option value="<?php echo $spot['spot_id']; ?>">
                                            <?php echo $spot['name']; ?> 
                                            (<?php echo getSpotTypeText($spot['type']); ?>, <?php echo $spot['location']; ?>)
                                        </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="mb-3">
                                    <label for="start_date" class="form-label">Startdatum:</label>
                                    <input type="date" name="start_date" id="start_date" class="form-control" value="<?php echo date('Y-m-d'); ?>" required>
                                </div>
                            </div>
                            <div class="col-md-4 d-flex align-items-end">
                                <div class="mb-3">
                                    <button type="submit" class="btn btn-primary">Tilldela plats</button>
                                    <a href="<?php echo SITE_URL; ?>/admin/parking_queue_management.php" class="btn btn-secondary ms-2">Avbryt</a>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <div class="row mb-4">
        <div class="col-lg-6">
            <!-- Aktiva köer -->
            <div class="card shadow-sm mb-4">
                <div class="card-header bg-primary text-white">
                    <h5 class="card-title mb-0">Aktiva köer</h5>
                </div>
                <div class="card-body">
                    <?php if (empty($activeQueues)): ?>
                        <p class="text-muted">Det finns inga aktiva köer för tillfället.</p>
                    <?php else: ?>
                        <div class="table-responsive">
                            <table class="table table-striped table-hover">
                                <thead>
                                    <tr>
                                        <th>Position</th>
                                        <th>Medlem</th>
                                        <th>Registrerad</th>
                                        <th>Åtgärder</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php 
                                    $currentQueueType = '';
                                    foreach ($activeQueues as $queue): 
                                        // Gruppera efter kötyp med visuell separator
                                        if ($currentQueueType !== $queue['queue_name']) {
                                            $currentQueueType = $queue['queue_name'];
                                            echo '<tr class="table-secondary"><td colspan="4"><strong>' . $currentQueueType . '</strong></td></tr>';
                                        }
                                    ?>
                                        <tr>
                                            <td><?php echo $queue['position'] + 1; ?></td>
                                            <td>
                                                <?php echo $queue['first_name'] . ' ' . $queue['last_name']; ?>
                                                <div class="small text-muted"><?php echo $queue['email']; ?></div>
                                            </td>
                                            <td>
                                                <?php echo formatDate($queue['registration_date'], 'Y-m-d'); ?>
                                            </td>
                                            <td>
                                                <div class="btn-group btn-group-sm">
                                                    <a href="<?php echo SITE_URL; ?>/admin/parking_queue_management.php?action=assign&id=<?php echo $queue['queue_id']; ?>" class="btn btn-outline-success">
                                                        <i class="fas fa-key"></i> Tilldela plats
                                                    </a>
                                                    <a href="<?php echo SITE_URL; ?>/admin/parking_queue_management.php?action=remove_from_queue&id=<?php echo $queue['queue_id']; ?>" class="btn btn-outline-danger" onclick="return confirm('Är du säker på att du vill ta bort användaren från kön?')">
                                                        <i class="fas fa-times"></i> Ta bort
                                                    </a>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Lägga till i kö -->
            <div class="card shadow-sm">
                <div class="card-header bg-primary text-white">
                    <h5 class="card-title mb-0">Lägg till medlem i kö</h5>
                </div>
                <div class="card-body">
                    <form method="post" action="">
                        <input type="hidden" name="csrf_token" value="<?php echo generateCSRFToken(); ?>">
                        
                        <div class="mb-3">
                            <label for="user_id" class="form-label">Medlem *</label>
                            <select class="form-select" id="user_id" name="user_id" required>
                                <option value="">Välj medlem...</option>
                                <?php foreach ($users as $user): ?>
                                    <option value="<?php echo $user['user_id']; ?>">
                                        <?php echo $user['first_name'] . ' ' . $user['last_name']; ?> 
                                        (<?php echo $user['email']; ?>)
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <div class="mb-3">
                            <label for="queue_type_id" class="form-label">Kötyp *</label>
                            <select class="form-select" id="queue_type_id" name="queue_type_id" required>
                                <option value="">Välj kötyp...</option>
                                <?php foreach ($queueTypes as $queueType): ?>
                                    <option value="<?php echo $queueType['queue_type_id']; ?>">
                                        <?php echo $queueType['name']; ?> 
                                        (<?php echo getSpotTypeText($queueType['spot_type']); ?>)
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <button type="submit" name="add_to_queue" class="btn btn-primary">Lägg till i kö</button>
                    </form>
                </div>
            </div>
        </div>

        <div class="col-lg-6">
            <!-- Aktiva tilldelningar -->
            <div class="card shadow-sm">
                <div class="card-header bg-primary text-white">
                    <h5 class="card-title mb-0">Aktiva parkeringstilldelningar</h5>
                </div>
                <div class="card-body">
                    <?php if (empty($activeAssignments)): ?>
                        <p class="text-muted">Det finns inga aktiva parkeringstilldelningar för tillfället.</p>
                    <?php else: ?>
                        <div class="table-responsive">
                            <table class="table table-striped table-hover">
                                <thead>
                                    <tr>
                                        <th>Plats</th>
                                        <th>Typ</th>
                                        <th>Medlem</th>
                                        <th>Startdatum</th>
                                        <th>Åtgärder</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php 
                                    $currentSpotType = '';
                                    foreach ($activeAssignments as $assignment): 
                                        // Gruppera efter platstyp med visuell separator
                                        if ($currentSpotType !== $assignment['type']) {
                                            $currentSpotType = $assignment['type'];
                                            echo '<tr class="table-secondary"><td colspan="5"><strong>' . getSpotTypeText($currentSpotType) . '</strong></td></tr>';
                                        }
                                    ?>
                                        <tr>
                                            <td><?php echo $assignment['spot_name']; ?></td>
                                            <td><?php echo $assignment['location']; ?></td>
                                            <td>
                                                <?php echo $assignment['first_name'] . ' ' . $assignment['last_name']; ?>
                                                <div class="small text-muted"><?php echo $assignment['email']; ?></div>
                                            </td>
                                            <td><?php echo formatDate($assignment['start_date'], 'Y-m-d'); ?></td>
                                            <td>
                                                <a href="<?php echo SITE_URL; ?>/admin/parking_queue_management.php?action=end_assignment&assignment_id=<?php echo $assignment['assignment_id']; ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('Är du säker på att du vill avsluta denna parkeringstilldelning?')">
                                                    <i class="fas fa-sign-out-alt"></i> Avsluta
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
// Inkludera sidfot
include(TEMPLATES_PATH . '/footer.php');
?>