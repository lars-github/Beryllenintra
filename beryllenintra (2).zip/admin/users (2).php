<?php
/**
 * Användarhantering för administratörer
 * 
 * Denna sida låter administratörer hantera användare, ändra lösenord, etc.
 */

// Initiera systemet
require_once('../init.php');

// Kontrollera att användaren är inloggad och har admin-rättigheter
if (!$auth->isLoggedIn() || !($auth->hasRole('admin') || $auth->hasRole('superadmin'))) {
    $_SESSION['flash_message'] = 'Du har inte behörighet att visa denna sida.';
    $_SESSION['flash_type'] = 'warning';
    redirect(SITE_URL . '/index.php');
}

// Ladda Users-klassen
require_once('../includes/classes/Users.php');
$userManager = new UserManager();

// Hantera borttagning av användare (endast superadmin)
if (isset($_GET['action']) && $_GET['action'] == 'delete' && isset($_GET['id'])) {
    if ($auth->hasRole('superadmin')) {
        $userId = (int)$_GET['id'];
        if ($userManager->deleteUser($userId)) {
            $_SESSION['flash_message'] = 'Användaren har tagits bort.';
            $_SESSION['flash_type'] = 'success';
        } else {
            $_SESSION['flash_message'] = 'Kunde inte ta bort användaren.';
            $_SESSION['flash_type'] = 'danger';
        }
    } else {
        $_SESSION['flash_message'] = 'Du har inte behörighet att ta bort användare.';
        $_SESSION['flash_type'] = 'warning';
    }
    redirect(SITE_URL . '/admin/users.php');
}

// Hantera lösenordsändring
$passwordChanged = false;
$passwordError = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['change_password'])) {
    // Validera CSRF-token
    if (!validateCSRFToken($_POST['csrf_token'] ?? '')) {
        $passwordError = 'Ogiltigt formulär. Försök igen.';
    } else {
        $userId = (int)$_POST['user_id'];
        $newPassword = $_POST['new_password'] ?? '';
        $confirmPassword = $_POST['confirm_password'] ?? '';
        
        // Validera lösenord
        if (empty($newPassword)) {
            $passwordError = 'Du måste ange ett lösenord.';
        } elseif (strlen($newPassword) < 6) {
            $passwordError = 'Lösenordet måste vara minst 6 tecken långt.';
        } elseif ($newPassword !== $confirmPassword) {
            $passwordError = 'Lösenorden matchar inte.';
        } else {
            // Uppdatera lösenord
            $result = $userManager->updateUser($userId, ['password' => $newPassword]);
            
            if ($result['success']) {
                $passwordChanged = true;
                $_SESSION['flash_message'] = 'Lösenordet har uppdaterats.';
                $_SESSION['flash_type'] = 'success';
                redirect(SITE_URL . '/admin/users.php');
            } else {
                $passwordError = $result['message'];
            }
        }
    }
}

// Hantera statusändring
if (isset($_GET['action']) && $_GET['action'] == 'toggle_status' && isset($_GET['id'])) {
    $userId = (int)$_GET['id'];
    $user = $userManager->getUser($userId);
    
    if ($user) {
        $newStatus = ($user['status'] == 'active') ? 'inactive' : 'active';
        $result = $userManager->updateUser($userId, ['status' => $newStatus]);
        
        if ($result['success']) {
            $_SESSION['flash_message'] = 'Användarstatus har uppdaterats.';
            $_SESSION['flash_type'] = 'success';
        } else {
            $_SESSION['flash_message'] = $result['message'];
            $_SESSION['flash_type'] = 'danger';
        }
    } else {
        $_SESSION['flash_message'] = 'Användaren hittades inte.';
        $_SESSION['flash_type'] = 'danger';
    }
    
    redirect(SITE_URL . '/admin/users.php');
}

// Hantera rollförändring (endast superadmin)
if (isset($_GET['action']) && $_GET['action'] == 'change_role' && isset($_GET['id']) && isset($_GET['role'])) {
    if ($auth->hasRole('superadmin')) {
        $userId = (int)$_GET['id'];
        $newRole = $_GET['role'];
        
        // Validera roll
        $validRoles = ['member', 'admin', 'superadmin'];
        if (in_array($newRole, $validRoles)) {
            $result = $userManager->updateUser($userId, ['role' => $newRole]);
            
            if ($result['success']) {
                $_SESSION['flash_message'] = 'Användarroll har uppdaterats.';
                $_SESSION['flash_type'] = 'success';
            } else {
                $_SESSION['flash_message'] = $result['message'];
                $_SESSION['flash_type'] = 'danger';
            }
        } else {
            $_SESSION['flash_message'] = 'Ogiltig roll.';
            $_SESSION['flash_type'] = 'danger';
        }
    } else {
        $_SESSION['flash_message'] = 'Du har inte behörighet att ändra roller.';
        $_SESSION['flash_type'] = 'warning';
    }
    
    redirect(SITE_URL . '/admin/users.php');
}

// Hämta användardetaljer om en användare är vald
$selectedUser = null;
if (isset($_GET['id'])) {
    $userId = (int)$_GET['id'];
    $selectedUser = $userManager->getUser($userId);
}

// Filtrera användarlistan
$statusFilter = $_GET['status'] ?? null;
$roleFilter = $_GET['role'] ?? null;
$users = $userManager->getUsers($statusFilter, $roleFilter);

// Sidspecifika inställningar
$pageTitle = 'Användarhantering';
$pageDescription = 'Administrera användare i systemet';

// Inkludera sidhuvud
include(TEMPLATES_PATH . '/header.php');
?>

<div class="container py-4">
    <div class="row mb-4">
        <div class="col-12">
            <h1 class="mb-4">Användarhantering</h1>
        </div>
    </div>

    <div class="row">
        <!-- Användarlista -->
        <div class="col-md-8">
            <div class="card shadow-sm">
                <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
                    <h5 class="card-title mb-0">Användare</h5>
                    <a href="<?php echo SITE_URL; ?>/admin/user_create.php" class="btn btn-sm btn-light">
                        <i class="fas fa-plus-circle me-1"></i> Ny användare
                    </a>
                </div>
                <div class="card-body">
                    <!-- Filter -->
                    <div class="row mb-3">
                        <div class="col-md-12">
                            <form class="row g-3" method="get" action="">
                                <div class="col-md-4">
                                    <label for="status" class="form-label">Status</label>
                                    <select class="form-select form-select-sm" id="status" name="status">
                                        <option value="">Alla</option>
                                        <option value="active" <?php echo ($statusFilter === 'active') ? 'selected' : ''; ?>>Aktiv</option>
                                        <option value="inactive" <?php echo ($statusFilter === 'inactive') ? 'selected' : ''; ?>>Inaktiv</option>
                                        <option value="pending" <?php echo ($statusFilter === 'pending') ? 'selected' : ''; ?>>Avvaktar</option>
                                    </select>
                                </div>
                                <div class="col-md-4">
                                    <label for="role" class="form-label">Roll</label>
                                    <select class="form-select form-select-sm" id="role" name="role">
                                        <option value="">Alla</option>
                                        <option value="member" <?php echo ($roleFilter === 'member') ? 'selected' : ''; ?>>Medlem</option>
                                        <option value="admin" <?php echo ($roleFilter === 'admin') ? 'selected' : ''; ?>>Admin</option>
                                        <option value="superadmin" <?php echo ($roleFilter === 'superadmin') ? 'selected' : ''; ?>>Superadmin</option>
                                    </select>
                                </div>
                                <div class="col-md-4 d-flex align-items-end">
                                    <button type="submit" class="btn btn-primary btn-sm">Filtrera</button>
                                    <?php if ($statusFilter || $roleFilter): ?>
                                        <a href="<?php echo SITE_URL; ?>/admin/users.php" class="btn btn-outline-secondary btn-sm ms-2">Rensa</a>
                                    <?php endif; ?>
                                </div>
                            </form>
                        </div>
                    </div>

                    <!-- Användartabell -->
                    <div class="table-responsive">
                        <table class="table table-striped table-hover">
                            <thead>
                                <tr>
                                    <th>Namn</th>
                                    <th>E-post</th>
                                    <th>Roll</th>
                                    <th>Status</th>
                                    <th>Lägenhet</th>
                                    <th>Åtgärder</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (empty($users)): ?>
                                    <tr>
                                        <td colspan="6" class="text-center">Inga användare hittades.</td>
                                    </tr>
                                <?php else: ?>
                                    <?php foreach ($users as $user): ?>
                                        <tr <?php echo (isset($_GET['id']) && $_GET['id'] == $user['user_id']) ? 'class="table-primary"' : ''; ?>>
                                            <td>
                                                <?php echo $user['first_name'] . ' ' . $user['last_name']; ?>
                                            </td>
                                            <td><?php echo $user['email']; ?></td>
                                            <td>
                                                <?php
                                                    switch ($user['role']) {
                                                        case 'superadmin':
                                                            echo '<span class="badge bg-danger">Superadmin</span>';
                                                            break;
                                                        case 'admin':
                                                            echo '<span class="badge bg-warning">Admin</span>';
                                                            break;
                                                        default:
                                                            echo '<span class="badge bg-info">Medlem</span>';
                                                    }
                                                ?>
                                            </td>
                                            <td>
                                                <?php
                                                    switch ($user['status']) {
                                                        case 'active':
                                                            echo '<span class="badge bg-success">Aktiv</span>';
                                                            break;
                                                        case 'inactive':
                                                            echo '<span class="badge bg-secondary">Inaktiv</span>';
                                                            break;
                                                        case 'pending':
                                                            echo '<span class="badge bg-warning">Avvaktar</span>';
                                                            break;
                                                    }
                                                ?>
                                            </td>
                                            <td>
                                                <?php if (!empty($user['BrfNR'])): ?>
                                                    <?php echo $user['BrfNR']; ?>
                                                    <?php if (!empty($user['LantmNR'])): ?>
                                                        (<?php echo $user['LantmNR']; ?>)
                                                    <?php endif; ?>
                                                <?php else: ?>
                                                    -
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <div class="btn-group btn-group-sm">
                                                    <a href="<?php echo SITE_URL; ?>/admin/users.php?id=<?php echo $user['user_id']; ?>" class="btn btn-outline-primary">
                                                        <i class="fas fa-edit"></i>
                                                    </a>
                                                    <a href="<?php echo SITE_URL; ?>/admin/users.php?action=toggle_status&id=<?php echo $user['user_id']; ?>" class="btn btn-outline-<?php echo ($user['status'] == 'active') ? 'secondary' : 'success'; ?>" data-bs-toggle="tooltip" title="<?php echo ($user['status'] == 'active') ? 'Inaktivera' : 'Aktivera'; ?> användare">
                                                        <i class="fas fa-<?php echo ($user['status'] == 'active') ? 'ban' : 'check'; ?>"></i>
                                                    </a>
                                                    <?php if ($auth->hasRole('superadmin')): ?>
                                                        <div class="btn-group btn-group-sm">
                                                            <button type="button" class="btn btn-outline-warning dropdown-toggle" data-bs-toggle="dropdown">
                                                                <i class="fas fa-user-tag"></i>
                                                            </button>
                                                            <ul class="dropdown-menu dropdown-menu-end">
                                                                <li>
                                                                    <a class="dropdown-item <?php echo ($user['role'] == 'member') ? 'active' : ''; ?>" href="<?php echo SITE_URL; ?>/admin/users.php?action=change_role&id=<?php echo $user['user_id']; ?>&role=member">
                                                                        <i class="fas fa-user me-2"></i> Medlem
                                                                    </a>
                                                                </li>
                                                                <li>
                                                                    <a class="dropdown-item <?php echo ($user['role'] == 'admin') ? 'active' : ''; ?>" href="<?php echo SITE_URL; ?>/admin/users.php?action=change_role&id=<?php echo $user['user_id']; ?>&role=admin">
                                                                        <i class="fas fa-user-cog me-2"></i> Admin
                                                                    </a>
                                                                </li>
                                                                <li>
                                                                    <a class="dropdown-item <?php echo ($user['role'] == 'superadmin') ? 'active' : ''; ?>" href="<?php echo SITE_URL; ?>/admin/users.php?action=change_role&id=<?php echo $user['user_id']; ?>&role=superadmin">
                                                                        <i class="fas fa-user-shield me-2"></i> Superadmin
                                                                    </a>
                                                                </li>
                                                            </ul>
                                                        </div>
                                                        <?php if ($user['user_id'] != $auth->getUserId()): ?>
                                                            <a href="<?php echo SITE_URL; ?>/admin/users.php?action=delete&id=<?php echo $user['user_id']; ?>" class="btn btn-outline-danger btn-delete" data-confirm="Är du säker på att du vill ta bort denna användare? Detta kan inte ångras.">
                                                                <i class="fas fa-trash-alt"></i>
                                                            </a>
                                                        <?php endif; ?>
                                                    <?php endif; ?>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Användardetaljer / Lösenordsändring -->
        <div class="col-md-4">
            <?php if ($selectedUser): ?>
                <div class="card shadow-sm mb-4">
                    <div class="card-header bg-primary text-white">
                        <h5 class="card-title mb-0">Användardetaljer</h5>
                    </div>
                    <div class="card-body">
                        <h5><?php echo $selectedUser['first_name'] . ' ' . $selectedUser['last_name']; ?></h5>
                        <p class="text-muted"><?php echo $selectedUser['email']; ?></p>
                        
                        <div class="row mb-2">
                            <div class="col-sm-4">
                                <strong>Användarnamn:</strong>
                            </div>
                            <div class="col-sm-8">
                                <?php echo $selectedUser['username']; ?>
                            </div>
                        </div>
                        
                        <div class="row mb-2">
                            <div class="col-sm-4">
                                <strong>Roll:</strong>
                            </div>
                            <div class="col-sm-8">
                                <?php 
                                    switch ($selectedUser['role']) {
                                        case 'superadmin':
                                            echo 'Superadmin';
                                            break;
                                        case 'admin':
                                            echo 'Admin';
                                            break;
                                        default:
                                            echo 'Medlem';
                                    }
                                ?>
                            </div>
                        </div>
                        
                        <div class="row mb-2">
                            <div class="col-sm-4">
                                <strong>Status:</strong>
                            </div>
                            <div class="col-sm-8">
                                <?php 
                                    switch ($selectedUser['status']) {
                                        case 'active':
                                            echo 'Aktiv';
                                            break;
                                        case 'inactive':
                                            echo 'Inaktiv';
                                            break;
                                        case 'pending':
                                            echo 'Avvaktar';
                                            break;
                                    }
                                ?>
                            </div>
                        </div>
                        
                        <?php if (!empty($selectedUser['phone'])): ?>
                        <div class="row mb-2">
                            <div class="col-sm-4">
                                <strong>Telefon:</strong>
                            </div>
                            <div class="col-sm-8">
                                <?php echo $selectedUser['phone']; ?>
                            </div>
                        </div>
                        <?php endif; ?>
                        
                        <?php if (!empty($selectedUser['BrfNR'])): ?>
                        <div class="row mb-2">
                            <div class="col-sm-4">
                                <strong>Lägenhet:</strong>
                            </div>
                            <div class="col-sm-8">
                                <?php echo $selectedUser['BrfNR']; ?>
                                <?php if (!empty($selectedUser['LantmNR'])): ?>
                                    (<?php echo $selectedUser['LantmNR']; ?>)
                                <?php endif; ?>
                            </div>
                        </div>
                        <?php endif; ?>
                        
                        <?php if (!empty($selectedUser['last_login'])): ?>
                        <div class="row mb-2">
                            <div class="col-sm-4">
                                <strong>Senaste inloggning:</strong>
                            </div>
                            <div class="col-sm-8">
                                <?php echo formatDate($selectedUser['last_login'], 'Y-m-d H:i'); ?>
                            </div>
                        </div>
                        <?php endif; ?>
                        
                        <div class="mt-3">
                            <a href="<?php echo SITE_URL; ?>/admin/user_edit.php?id=<?php echo $selectedUser['user_id']; ?>" class="btn btn-primary btn-sm">
                                <i class="fas fa-edit me-1"></i> Redigera användaruppgifter
                            </a>
                        </div>
                    </div>
                </div>
                
                <!-- Lösenordsändring -->
                <div class="card shadow-sm">
                    <div class="card-header bg-primary text-white">
                        <h5 class="card-title mb-0">Ändra lösenord</h5>
                    </div>
                    <div class="card-body">
                        <?php if ($passwordChanged): ?>
                            <div class="alert alert-success">
                                Lösenordet har uppdaterats.
                            </div>
                        <?php endif; ?>
                        
                        <?php if (!empty($passwordError)): ?>
                            <div class="alert alert-danger">
                                <?php echo $passwordError; ?>
                            </div>
                        <?php endif; ?>
                        
                        <form method="post" action="">
                            <input type="hidden" name="csrf_token" value="<?php echo generateCSRFToken(); ?>">
                            <input type="hidden" name="user_id" value="<?php echo $selectedUser['user_id']; ?>">
                            
                            <div class="mb-3">
                                <label for="new_password" class="form-label">Nytt lösenord *</label>
                                <input type="password" class="form-control" id="new_password" name="new_password" required>
                                <div class="form-text">Minst 6 tecken långt.</div>
                            </div>
                            
                            <div class="mb-3">
                                <label for="confirm_password" class="form-label">Bekräfta nytt lösenord *</label>
                                <input type="password" class="form-control" id="confirm_password" name="confirm_password" required>
                            </div>
                            
                            <button type="submit" name="change_password" class="btn btn-primary">Ändra lösenord</button>
                        </form>
                    </div>
                </div>
            <?php else: ?>
                <div class="card shadow-sm">
                    <div class="card-body">
                        <p class="text-muted">Välj en användare från listan för att visa detaljer och hantera lösenord.</p>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php
// Inkludera sidfot
include(TEMPLATES_PATH . '/footer.php');
?>