<?php
/**
 * Administratörssida för BRF Beryllen
 * 
 * Denna sida visar administratörens dashboard
 */

// Initiera systemet
require_once('../init.php');

// Kontrollera att användaren är inloggad och har adminrättigheter
if (!$auth->isLoggedIn() || !($auth->hasRole('admin') || $auth->hasRole('superadmin'))) {
    $_SESSION['flash_message'] = 'Du har inte behörighet att visa denna sida.';
    $_SESSION['flash_type'] = 'warning';
    redirect(SITE_URL . '/index.php');
}

// Hämta användardata
$userData = $auth->getUserData();

// Hämta statistik för dashboarden
$db = Database::getInstance();

// Antal aktiva medlemmar
$activeMembers = $db->getRow("SELECT COUNT(*) as count FROM users WHERE status = 'active' AND role = 'member'");
$activeMembersCount = $activeMembers ? $activeMembers['count'] : 0;

// Antal lägenheter
$apartments = $db->getRow("SELECT COUNT(*) as count FROM apartments");
$apartmentsCount = $apartments ? $apartments['count'] : 0;

// Antal ärenden
$tickets = $db->getRow("SELECT COUNT(*) as count FROM tickets WHERE status != 'closed'");
$ticketsCount = $tickets ? $tickets['count'] : 0;

// Antal bokningar idag
$todayBookings = $db->getRow("SELECT COUNT(*) as count FROM bookings WHERE DATE(start_time) = CURDATE() AND status = 'confirmed'");
$todayBookingsCount = $todayBookings ? $todayBookings['count'] : 0;

// Sidspecifika inställningar
$pageTitle = 'Admin Dashboard';
$pageDescription = 'Administratörspanel för BRF Beryllen';

// Inkludera sidhuvud
include(TEMPLATES_PATH . '/header.php');
?>

<div class="container py-4">
    <div class="row mb-4">
        <div class="col-md-12">
            <h1 class="mb-4">Administratörspanel</h1>
            <p class="lead">Välkommen till administratörspanelen, <?php echo $userData['first_name']; ?>!</p>
        </div>
    </div>
    
    <!-- Dashboard widgets -->
    <div class="row mb-4">
        <div class="col-md-3 mb-4">
            <div class="card dashboard-widget shadow-sm">
                <div class="card-body">
                    <div class="icon text-primary">
                        <i class="fas fa-users"></i>
                    </div>
                    <div class="value"><?php echo $activeMembersCount; ?></div>
                    <div class="label">Aktiva medlemmar</div>
                </div>
                <div class="card-footer bg-light">
                    <a href="<?php echo SITE_URL; ?>/admin/users.php" class="btn btn-sm btn-outline-primary w-100">Hantera medlemmar</a>
                </div>
            </div>
        </div>
        
        <div class="col-md-3 mb-4">
            <div class="card dashboard-widget shadow-sm">
                <div class="card-body">
                    <div class="icon text-success">
                        <i class="fas fa-building"></i>
                    </div>
                    <div class="value"><?php echo $apartmentsCount; ?></div>
                    <div class="label">Lägenheter</div>
                </div>
                <div class="card-footer bg-light">
                    <a href="<?php echo SITE_URL; ?>/admin/apartments.php" class="btn btn-sm btn-outline-success w-100">Hantera lägenheter</a>
                </div>
            </div>
        </div>
        
        <div class="col-md-3 mb-4">
            <div class="card dashboard-widget shadow-sm">
                <div class="card-body">
                    <div class="icon text-warning">
                        <i class="fas fa-ticket-alt"></i>
                    </div>
                    <div class="value"><?php echo $ticketsCount; ?></div>
                    <div class="label">Aktiva ärenden</div>
                </div>
                <div class="card-footer bg-light">
                    <a href="<?php echo SITE_URL; ?>/admin/tickets.php" class="btn btn-sm btn-outline-warning w-100">Hantera ärenden</a>
                </div>
            </div>
        </div>
        
        <div class="col-md-3 mb-4">
            <div class="card dashboard-widget shadow-sm">
                <div class="card-body">
                    <div class="icon text-info">
                        <i class="fas fa-calendar-check"></i>
                    </div>
                    <div class="value"><?php echo $todayBookingsCount; ?></div>
                    <div class="label">Bokningar idag</div>
                </div>
                <div class="card-footer bg-light">
                    <a href="<?php echo SITE_URL; ?>/admin/bookings.php" class="btn btn-sm btn-outline-info w-100">Hantera bokningar</a>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Admin funktioner -->
    <div class="row">
        <div class="col-md-6 mb-4">
            <div class="card shadow-sm h-100">
                <div class="card-header bg-primary text-white">
                    <h5 class="card-title mb-0">Administrations&shy;verktyg</h5>
                </div>
                <div class="card-body">
                    <div class="list-group">
                        <a href="<?php echo SITE_URL; ?>/admin/users.php" class="list-group-item list-group-item-action">
                            <i class="fas fa-users me-2"></i> Användarhantering
                        </a>
                        <a href="<?php echo SITE_URL; ?>/admin/news.php" class="list-group-item list-group-item-action">
                            <i class="fas fa-newspaper me-2"></i> Nyhetshantering
                        </a>
                        <a href="<?php echo SITE_URL; ?>/admin/documents.php" class="list-group-item list-group-item-action">
                            <i class="fas fa-file-alt me-2"></i> Dokumenthantering
                        </a>
                        <a href="<?php echo SITE_URL; ?>/admin/bookings.php" class="list-group-item list-group-item-action">
                            <i class="fas fa-calendar me-2"></i> Bokningshantering
                        </a>
                        <a href="<?php echo SITE_URL; ?>/admin/tickets.php" class="list-group-item list-group-item-action">
                            <i class="fas fa-ticket-alt me-2"></i> Ärendehantering
                        </a>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="col-md-6 mb-4">
            <div class="card shadow-sm h-100">
                <div class="card-header bg-primary text-white">
                    <h5 class="card-title mb-0">Systemadministration</h5>
                </div>
                <div class="card-body">
                    <div class="list-group">
                        <?php if ($auth->hasRole('superadmin')): ?>
                            <a href="<?php echo SITE_URL; ?>/admin/apartments.php" class="list-group-item list-group-item-action">
                                <i class="fas fa-building me-2"></i> Lägenhetsregister
                            </a>
                           <a href="<?php echo SITE_URL; ?>/admin/parking.php" class="list-group-item list-group-item-action">
                                <i class="fas fa-car me-2"></i> Parkeringshantering
                            </a>
                            <a href="<?php echo SITE_URL; ?>/admin/parking_queue_management.php" class="list-group-item list-group-item-action">
                                <i class="fas fa-list-ol me-2"></i> Parkeringskö
                            </a>
                            <a href="<?php echo SITE_URL; ?>/admin/config.php" class="list-group-item list-group-item-action">
                                <i class="fas fa-cogs me-2"></i> Systeminställningar

                            <a href="<?php echo SITE_URL; ?>/admin/logs.php" class="list-group-item list-group-item-action">
                                <i class="fas fa-list-alt me-2"></i> Aktivitetsloggar
                            </a>
                        <?php else: ?>
                            <div class="alert alert-info">
                                <i class="fas fa-info-circle me-2"></i> Du behöver superadmin-rättigheter för att komma åt systemadministrationen.
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
// Inkludera sidfot
include(TEMPLATES_PATH . '/footer.php');
?>