<?php
/**
 * Lägenhetshantering för administratörer
 * 
 * Denna sida låter administratörer hantera lägenheter och koppla ägare
 */

// Initiera systemet
require_once('../init.php');

// Kontrollera att användaren är inloggad och har admin-rättigheter
if (!$auth->isLoggedIn() || !($auth->hasRole('admin') || $auth->hasRole('superadmin'))) {
    $_SESSION['flash_message'] = 'Du har inte behörighet att visa denna sida.';
    $_SESSION['flash_type'] = 'warning';
    redirect(SITE_URL . '/index.php');
}

// Ladda User-klassen
require_once('../includes/classes/Users.php');
$user = new UserManager();

// Hämta databas
$db = Database::getInstance();

// Hantera tillägg/ändring av ägande
$ownershipMessage = '';
$ownershipError = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_ownership'])) {
    // Validera CSRF-token
    if (!validateCSRFToken($_POST['csrf_token'] ?? '')) {
        $ownershipError = 'Ogiltigt formulär. Försök igen.';
    } else {
        $apartmentId = (int)$_POST['apartment_id'];
        $userId = (int)$_POST['user_id'];
        $sharePercentage = floatval(str_replace(',', '.', $_POST['share_percentage']));
        $startDate = $_POST['start_date'];
        
        // Validera indata
        if (empty($apartmentId) || empty($userId)) {
            $ownershipError = 'Du måste välja både lägenhet och användare.';
        } elseif ($sharePercentage <= 0 || $sharePercentage > 100) {
            $ownershipError = 'Ägarandel måste vara mellan 0 och 100%.';
        } elseif (empty($startDate)) {
            $ownershipError = 'Du måste ange ett startdatum.';
        } else {
            // Kolla om användaren redan äger denna lägenhet
            $existingOwnership = $db->getRow(
                "SELECT * FROM ownership_history 
                WHERE user_id = ? AND apartment_id = ? AND end_date IS NULL",
                [$userId, $apartmentId]
            );
            
            if ($existingOwnership) {
                $ownershipError = 'Användaren äger redan denna lägenhet.';
            } else {
                // Lägg till ägarskap
                if ($userManager->addOwnership($userId, $apartmentId, $sharePercentage, $startDate)) {
                    $ownershipMessage = 'Ägarskap har lagts till.';
                    
                    // Uppdatera användarens huvudlägenhet om den inte redan har en
                    $user = $userManager->getUser($userId);
                    if (empty($user['apartment_id'])) {
                        $userManager->updateUser($userId, ['apartment_id' => $apartmentId]);
                    }
                } else {
                    $ownershipError = 'Kunde inte lägga till ägarskap.';
                }
            }
        }
    }
}

// Hantera avslutande av ägande
if (isset($_GET['action']) && $_GET['action'] == 'end_ownership' && isset($_GET['user_id']) && isset($_GET['apartment_id'])) {
    $userId = (int)$_GET['user_id'];
    $apartmentId = (int)$_GET['apartment_id'];
    $endDate = $_GET['end_date'] ?? date('Y-m-d');
    
    if ($userManager->endOwnership($userId, $apartmentId, $endDate)) {
        $_SESSION['flash_message'] = 'Ägarskap har avslutats.';
        $_SESSION['flash_type'] = 'success';
    } else {
        $_SESSION['flash_message'] = 'Kunde inte avsluta ägarskap.';
        $_SESSION['flash_type'] = 'danger';
    }
    
    redirect(SITE_URL . '/admin/apartments.php?id=' . $apartmentId);
}

// Hämta alla lägenheter
$apartments = $db->getRows("SELECT * FROM apartments ORDER BY BrfNR");

// Hämta alla aktiva användare
$activeUsers = $db->getRows(
    "SELECT user_id, first_name, last_name, email 
    FROM users 
    WHERE status = 'active' 
    ORDER BY last_name, first_name"
);

// Hämta detaljer för en specifik lägenhet om vald
$selectedApartment = null;
$currentOwners = [];
$ownershipHistory = [];

if (isset($_GET['id'])) {
    $apartmentId = (int)$_GET['id'];
    
    // Hämta lägenhetsinformation
    $selectedApartment = $db->getRow("SELECT * FROM apartments WHERE BrfNR = ?", [$apartmentId]);
    
    if ($selectedApartment) {
        // Hämta nuvarande ägare
        $currentOwners = $db->getRows(
            "SELECT oh.*, u.first_name, u.last_name, u.email
            FROM ownership_history oh
            JOIN users u ON oh.user_id = u.user_id
            WHERE oh.apartment_id = ? AND oh.end_date IS NULL
            ORDER BY oh.share_percentage DESC",
            [$apartmentId]
        );
        
        // Hämta tidigare ägare
        $ownershipHistory = $db->getRows(
            "SELECT oh.*, u.first_name, u.last_name, u.email
            FROM ownership_history oh
            JOIN users u ON oh.user_id = u.user_id
            WHERE oh.apartment_id = ? AND oh.end_date IS NOT NULL
            ORDER BY oh.end_date DESC",
            [$apartmentId]
        );
        
        // Debug-information för lägenheter utan historik
        if (empty($ownershipHistory)) {
            $allOwnershipRecords = $db->getRows(
                "SELECT * FROM ownership_history WHERE apartment_id = ?",
                [$apartmentId]
            );
            
            // Spara antalet poster som hittades direkt från tabellen
            $debugTotalRecords = count($allOwnershipRecords ?? []);
        }
    }
}

// Sidspecifika inställningar
$pageTitle = 'Lägenhetshantering';
$pageDescription = 'Administrera lägenheter och ägare';

// Inkludera sidhuvud
include(TEMPLATES_PATH . '/header.php');
?>

<div class="container py-4">
    <div class="row mb-4">
        <div class="col-12">
            <h1 class="mb-4">Lägenhetshantering</h1>
        </div>
    </div>

    <div class="row">
        <!-- Lägenhetslista -->
        <div class="col-md-5">
            <div class="card shadow-sm">
                <div class="card-header bg-primary text-white">
                    <h5 class="card-title mb-0">Lägenheter</h5>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-striped table-hover">
                            <thead>
                                <tr>
                                    <th>BRF nr</th>
                                    <th>Lantm nr</th>
                                    <th>Adress</th>
                                    <th>Area</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (empty($apartments)): ?>
                                    <tr>
                                        <td colspan="4" class="text-center">Inga lägenheter hittades.</td>
                                    </tr>
                                <?php else: ?>
                                    <?php foreach ($apartments as $apartment): ?>
                                        <tr class="<?php echo (isset($_GET['id']) && $_GET['id'] == $apartment['BrfNR']) ? 'table-primary' : ''; ?>">
                                            <td>
                                                <a href="<?php echo SITE_URL; ?>/admin/apartments.php?id=<?php echo $apartment['BrfNR']; ?>">
                                                    <?php echo $apartment['BrfNR']; ?>
                                                </a>
                                            </td>
                                            <td><?php echo $apartment['LantmNR']; ?></td>
                                            <td><?php echo $apartment['uppg']; ?></td>
                                            <td><?php echo $apartment['area']; ?> m²</td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Lägenhetsdetaljer och ägare -->
        <div class="col-md-7">
            <?php if ($selectedApartment): ?>
                <div class="card shadow-sm mb-4">
                    <div class="card-header bg-primary text-white">
                        <h5 class="card-title mb-0">Lägenhetsdetaljer</h5>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-6">
                                <h4>Lägenhet <?php echo $selectedApartment['BrfNR']; ?></h4>
                                <?php if (!empty($selectedApartment['LantmNR'])): ?>
                                <p class="text-muted">Lantmäteri nr: <?php echo $selectedApartment['LantmNR']; ?></p>
                                <?php endif; ?>
                                
                                <div class="row mb-2">
                                    <div class="col-sm-4">
                                        <strong>Adress:</strong>
                                    </div>
                                    <div class="col-sm-8">
                                        <?php echo $selectedApartment['uppg']; ?>
                                    </div>
                                </div>
                                
                                <div class="row mb-2">
                                    <div class="col-sm-4">
                                        <strong>Våning:</strong>
                                    </div>
                                    <div class="col-sm-8">
                                        <?php echo $selectedApartment['floor']; ?>
                                    </div>
                                </div>
                                
                                <div class="row mb-2">
                                    <div class="col-sm-4">
                                        <strong>Area:</strong>
                                    </div>
                                    <div class="col-sm-8">
                                        <?php echo $selectedApartment['area']; ?> m²
                                    </div>
                                </div>
                                
                                <div class="row mb-2">
                                    <div class="col-sm-4">
                                        <strong>Antal rum:</strong>
                                    </div>
                                    <div class="col-sm-8">
                                        <?php echo $selectedApartment['antrum']; ?>
                                    </div>
                                </div>
                                
                                <div class="row mb-2">
                                    <div class="col-sm-4">
                                        <strong>Typ:</strong>
                                    </div>
                                    <div class="col-sm-8">
                                        <?php echo $selectedApartment['typ']; ?>
                                    </div>
                                </div>
                                
                                <div class="row mb-2">
                                    <div class="col-sm-4">
                                        <strong>Balkong/ terrass:</strong>
                                    </div>
                                    <?php if (!empty($selectedApartment['balkterrass'])): ?>
                                    <div class="col-sm-8">
                                        <?php echo $selectedApartment['balkterrass'] == 'B' ? 'Balkong' : 'Terrass'; ?>
                                    </div>
                                    <?php else: ?>
                                    -
                                    <?php endif; ?>                                    
                                </div>

                            </div>
                            
                            <div class="col-md-6">
                                <h5>Nuvarande ägare</h5>
                                <?php if (empty($currentOwners)): ?>
                                    <p class="text-muted">Ingen nuvarande ägare registrerad.</p>
                                <?php else: ?>
                                    <ul class="list-group">
                                        <?php foreach ($currentOwners as $owner): ?>
                                            <li class="list-group-item d-flex justify-content-between align-items-center">
                                                <div>
                                                    <strong><?php echo $owner['first_name'] . ' ' . $owner['last_name']; ?></strong><br>
                                                    <small><?php echo $owner['email']; ?></small><br>
                                                    <small class="text-muted">Sedan: <?php echo formatDate($owner['start_date']); ?></small>
                                                </div>
                                                <div class="text-end">
                                                    <span class="badge bg-primary"><?php echo number_format((float)$owner['share_percentage'], 1, ',', ' '); ?>%</span>
                                                    <a href="<?php echo SITE_URL; ?>/admin/apartments.php?action=end_ownership&user_id=<?php echo $owner['user_id']; ?>&apartment_id=<?php echo $selectedApartment['BrfNR']; ?>" class="btn btn-sm btn-outline-danger ms-2" data-confirm="Är du säker på att du vill avsluta detta ägarskap?">
                                                        <i class="fas fa-times"></i>
                                                    </a>
                                                </div>
                                            </li>
                                        <?php endforeach; ?>
                                    </ul>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Lägg till ägare -->
                <div class="card shadow-sm mb-4">
                    <div class="card-header bg-primary text-white">
                        <h5 class="card-title mb-0">Lägg till ägare</h5>
                    </div>
                    <div class="card-body">
                        <?php if (!empty($ownershipMessage)): ?>
                            <div class="alert alert-success">
                                <?php echo $ownershipMessage; ?>
                            </div>
                        <?php endif; ?>
                        
                        <?php if (!empty($ownershipError)): ?>
                            <div class="alert alert-danger">
                                <?php echo $ownershipError; ?>
                            </div>
                        <?php endif; ?>
                        
                        <form method="post" action="">
                            <input type="hidden" name="csrf_token" value="<?php echo generateCSRFToken(); ?>">
                            <input type="hidden" name="apartment_id" value="<?php echo $selectedApartment['BrfNR']; ?>">
                            
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label for="user_id" class="form-label">Användare *</label>
                                    <select class="form-select" id="user_id" name="user_id" required>
                                        <option value="">Välj användare</option>
                                        <?php foreach ($activeUsers as $user): ?>
                                            <option value="<?php echo $user['user_id']; ?>">
                                                <?php echo $user['first_name'] . ' ' . $user['last_name'] . ' (' . $user['email'] . ')'; ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                
                                <div class="col-md-6 mb-3">
                                    <label for="share_percentage" class="form-label">Ägarandel (%) *</label>
                                    <input type="number" class="form-control" id="share_percentage" name="share_percentage" step="0.1" min="0.1" max="100" value="100" required>
                                </div>
                            </div>
                            
                            <div class="mb-3">
                                <label for="start_date" class="form-label">Startdatum *</label>
                                <input type="date" class="form-control" id="start_date" name="start_date" value="<?php echo date('Y-m-d'); ?>" required>
                            </div>
                            
                            <button type="submit" name="add_ownership" class="btn btn-primary">Lägg till ägare</button>
                        </form>
                    </div>
                </div>
                
                <!-- Ägarhistorik -->
                <div class="card shadow-sm">
                    <div class="card-header bg-primary text-white">
                        <h5 class="card-title mb-0">Ägarhistorik</h5>
                    </div>
                    <div class="card-body">
                        <?php if (!empty($ownershipHistory)): ?>
                        <div class="table-responsive">
                            <table class="table table-sm">
                                <thead>
                                    <tr>
                                        <th>Namn</th>
                                        <th>Period</th>
                                        <th>Andel</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($ownershipHistory as $history): ?>
                                        <tr>
                                            <td>
                                                <strong><?php echo $history['first_name'] . ' ' . $history['last_name']; ?></strong><br>
                                                <small><?php echo $history['email']; ?></small>
                                            </td>
                                            <td>
                                                <?php echo formatDate($history['start_date']); ?> - <?php echo formatDate($history['end_date']); ?>
                                            </td>
                                            <td><?php echo number_format((float)$history['share_percentage'], 1, ',', ' '); ?>%</td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                        <?php else: ?>
                            <p class="text-muted">Ingen tidigare ägarhistorik hittad för denna lägenhet.</p>
                            
                            <?php if (isset($debugTotalRecords)): ?>
                            <div class="mt-3 p-3 bg-light rounded">
                                <h6>Debug-information</h6>
                                <p>Totalt antal ägarposter i databasen för denna lägenhet: <strong><?php echo $debugTotalRecords; ?></strong></p>
                                <p class="mb-0 small">Notera: Endast avslutade ägarskap (med slutdatum) visas i ägarhistoriken. Aktiva ägarskap visas under "Nuvarande ägare".</p>
                            </div>
                            <?php endif; ?>
                        <?php endif; ?>
                    </div>
                </div>
            <?php else: ?>
                <div class="card shadow-sm">
                    <div class="card-body">
                        <p class="text-muted">Välj en lägenhet från listan för att visa detaljer och hantera ägare.</p>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php
// Inkludera sidfot
include(TEMPLATES_PATH . '/footer.php');
?>