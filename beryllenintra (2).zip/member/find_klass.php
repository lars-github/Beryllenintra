<?php
/**
 * Diagnostiskt skript för att hitta användarklassen i systemet
 */

// Initiera systemet
require_once('../init.php');

// Första steget: visa tillgängliga klasser i init.php
echo "<h2>Tillgängliga klasser efter init.php:</h2>";
echo "<pre>";
print_r(get_declared_classes());
echo "</pre>";

// Visa om auth existerar
echo "<h2>Auth objekt:</h2>";
echo "Auth-klassen: " . get_class($auth) . "<br>";
echo "Auth-metoder: <pre>";
print_r(get_class_methods($auth));
echo "</pre>";

// Kontrollera vanliga platser för User-klassen
echo "<h2>Sökvägar för User-klassen:</h2>";
$paths = [
    dirname(__DIR__) . '/classes/User.php',
    dirname(__DIR__) . '/classes/Users.php',
    dirname(__DIR__) . '/includes/classes/User.php',
    dirname(__DIR__) . '/models/User.php',
    dirname(__DIR__) . '/inc/class-user.php',
];

foreach ($paths as $path) {
    echo "Söker: $path - " . (file_exists($path) ? "HITTAD!" : "Finns ej") . "<br>";
}

// Visa projektstruktur om möjligt
echo "<h2>Projektstruktur:</h2>";
$baseDir = dirname(__DIR__);
echo "Bas-katalog: $baseDir<br>";
echo "Innehåll:<br><ul>";
foreach (scandir($baseDir) as $item) {
    if ($item == '.' || $item == '..') continue;
    echo "<li>$item" . (is_dir($baseDir . '/' . $item) ? '/' : '') . "</li>";
    
    // Visa innehåll i classes eller includes om de existerar
    if (is_dir($baseDir . '/' . $item) && in_array($item, ['classes', 'includes', 'models', 'inc'])) {
        echo "<ul>";
        foreach (scandir($baseDir . '/' . $item) as $subitem) {
            if ($subitem == '.' || $subitem == '..') continue;
            echo "<li>$subitem</li>";
        }
        echo "</ul>";
    }
}
echo "</ul>";

// Försök att utforska olika user-klasser
echo "<h2>Försöker hitta rätt användarklassnamn:</h2>";
$possibleClasses = ['User', 'Users', 'UserModel', 'Member', 'Members', 'BrfUser', 'UserHandler'];

foreach ($possibleClasses as $className) {
    echo "Testar $className: ";
    if (class_exists($className)) {
        echo "HITTAD!<br>";
        echo "Metoder för $className: <pre>";
        print_r(get_class_methods($className));
        echo "</pre>";
    } else {
        echo "Finns ej<br>";
    }
}
?>