<?php
// test.php
echo "Aktuell katalog: " . __DIR__ . "<br>";
echo "Föräldrakatalog: " . dirname(__DIR__) . "<br>";

// Kontrollera om includes-mappen finns
$includesPath = dirname(__DIR__) . '/includes';
echo "Includes-sökväg: " . $includesPath . "<br>";
echo "Includes finns: " . (is_dir($includesPath) ? 'Ja' : 'Nej') . "<br>";

// Kontrollera om classes-mappen finns
$classesPath = $includesPath . '/classes';
echo "Classes-sökväg: " . $classesPath . "<br>";
echo "Classes finns: " . (is_dir($classesPath) ? 'Ja' : 'Nej') . "<br>";

// Lista filer om mappen finns
if (is_dir($classesPath)) {
    echo "Filer i classes-mappen: <pre>";
    print_r(scandir($classesPath));
    echo "</pre>";
}
?>