<?php
/**
 * Medlemssidor för BRF Beryllen
 * 
 * Denna sida visar medlemmarnas startsida/dashboard
 */

// Initiera systemet
require_once('../init.php');
require_once('../includes/classes/Users.php');

// Kontrollera att användaren är inloggad och har tillräckliga rättigheter
if (!$auth->isLoggedIn() || !$auth->hasRole('member')) {
    $_SESSION['flash_message'] = 'Du måste vara inloggad för att se denna sida.';
    $_SESSION['flash_type'] = 'warning';
    redirect(SITE_URL . '/login.php');
}

// Hämta användardata
$userData = $auth->getUserData();
$user = new UserManager();
$userDetails = $user->getUser($userData['user_id']);

// Hämta lägenhetsdata
$db = Database::getInstance();
$apartment = null;
if (!empty($userDetails['apartment_id'])) {
    $apartment = $db->getRow(
        "SELECT a.*, 
        (SELECT share_percentage FROM ownership_history 
         WHERE apartment_id = a.BrfNR 
         AND user_id = ? 
         AND end_date IS NULL 
         LIMIT 1) as share_percentage
        FROM apartments a 
        WHERE a.BrfNR = ?",
        [$userData['user_id'], $userDetails['apartment_id']]
    );
}

// Hämta användarens aktiva bokningar
$bookings = $db->getRows(
    "SELECT b.*, r.name as resource_name, r.type as resource_type
    FROM bookings b
    JOIN resources r ON b.resource_id = r.resource_id
    WHERE b.user_id = ? AND b.end_time >= NOW() AND b.status = 'confirmed'
    ORDER BY b.start_time ASC
    LIMIT 5",
    [$userData['user_id']]
);

// Hämta användarens aktuella ärenden
$tickets = $db->getRows(
    "SELECT t.*, 
    (SELECT COUNT(*) FROM ticket_updates WHERE ticket_id = t.ticket_id) as updates_count
    FROM tickets t
    WHERE t.user_id = ? AND t.status != 'closed'
    ORDER BY t.created_at DESC
    LIMIT 5",
    [$userData['user_id']]
);

// Hämta de senaste nyheterna
$news = $db->getRows(
    "SELECT n.*, u.first_name, u.last_name 
    FROM news n
    LEFT JOIN users u ON n.created_by = u.user_id
    WHERE n.visibility IN ('public', 'member')
    ORDER BY n.is_pinned DESC, n.created_at DESC
    LIMIT 3",
    []
);

// Hämta användarens parkeringsköer
$parkingQueues = $db->getRows(
    "SELECT pq.*, qt.name as queue_name, 
    (SELECT COUNT(*) FROM parking_queue WHERE queue_type_id = pq.queue_type_id AND (position < pq.position OR (position = pq.position AND registration_date < pq.registration_date))) as position_in_queue
    FROM parking_queue pq
    JOIN queue_types qt ON pq.queue_type_id = qt.queue_type_id
    WHERE pq.user_id = ? AND pq.status = 'active'",
    [$userData['user_id']]
);

// Sidspecifika inställningar
$pageTitle = 'Medlemssidor';
$pageDescription = 'Medlemssidor för boende i BRF Beryllen';

// Inkludera sidhuvud
include(TEMPLATES_PATH . '/header.php');
?>

<div class="container py-4">
    <div class="row mb-4">
        <div class="col-md-12">
            <h1 class="mb-4">Välkommen, <?php echo $userData['first_name']; ?>!</h1>
        </div>
    </div>

    <div class="row mb-4">
        <!-- Personlig information -->
        <div class="col-md-6 mb-4">
            <div class="card shadow-sm h-100">
                <div class="card-header bg-primary text-white">
                    <h5 class="card-title mb-0">Min profil</h5>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-sm-4">
                            <strong>Namn:</strong>
                        </div>
                        <div class="col-sm-8">
                            <?php echo $userData['first_name'] . ' ' . $userData['last_name']; ?>
                        </div>
                    </div>
                    <div class="row mt-2">
                        <div class="col-sm-4">
                            <strong>E-post:</strong>
                        </div>
                        <div class="col-sm-8">
                            <?php echo $userData['email']; ?>
                        </div>
                    </div>
                    <?php if (!empty($userData['phone'])): ?>
                    <div class="row mt-2">
                        <div class="col-sm-4">
                            <strong>Telefon:</strong>
                        </div>
                        <div class="col-sm-8">
                            <?php echo $userData['phone']; ?>
                        </div>
                    </div>
                    <?php endif; ?>
                    <div class="row mt-2">
                        <div class="col-sm-4">
                            <strong>Användarnamn:</strong>
                        </div>
                        <div class="col-sm-8">
                            <?php echo $userData['username']; ?>
                        </div>
                    </div>
                    <div class="mt-3">
                        <a href="<?php echo SITE_URL; ?>/member/profile.php" class="btn btn-outline-primary btn-sm">
                            <i class="fas fa-user-edit me-1"></i> Redigera profil
                        </a>
                    </div>
                </div>
            </div>
        </div>

        <!-- Lägenhetsinformation -->
        <div class="col-md-6 mb-4">
            <div class="card shadow-sm h-100">
                <div class="card-header bg-primary text-white">
                    <h5 class="card-title mb-0">Min lägenhet</h5>
                </div>
                <div class="card-body">
                    <?php if ($apartment): ?>
                        <div class="row">
                            <div class="col-sm-4">
                                <strong>Lägenhetsnr:</strong>
                            </div>
                            <div class="col-sm-8">
                                <?php echo $apartment['LantmNR']; ?> (Internt nr: <?php echo $apartment['BrfNR']; ?>)
                            </div>
                        </div>
                        <div class="row mt-2">
                            <div class="col-sm-4">
                                <strong>Adress:</strong>
                            </div>
                            <div class="col-sm-8">
                                <?php echo $apartment['uppg']; ?>, vån <?php echo $apartment['floor']; ?>
                            </div>
                        </div>
                        <div class="row mt-2">
                            <div class="col-sm-4">
                                <strong>Storlek:</strong>
                            </div>
                            <div class="col-sm-8">
                                <?php echo $apartment['area']; ?> m², <?php echo $apartment['antrum']; ?> rum
                            </div>
                        </div>
                        <?php if (!empty($apartment['share_percentage'])): ?>
                        <div class="row mt-2">
                            <div class="col-sm-4">
                                <strong>Ägarandel:</strong>
                            </div>
                            <div class="col-sm-8">
                                <?php echo number_format($apartment['share_percentage'], 1, ',', ' '); ?> %
                            </div>
                        </div>
                        <?php endif; ?>
                    <?php else: ?>
                        <p class="text-muted">Ingen lägenhet registrerad för ditt konto.</p>
                        <p>Om du nyligen har flyttat in, kontakta styrelsen för att koppla din lägenhet till ditt konto.</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <div class="row mb-4">
        <!-- Kommande bokningar -->
        <div class="col-md-6 mb-4">
            <div class="card shadow-sm h-100">
                <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
                    <h5 class="card-title mb-0">Mina bokningar</h5>
                    <a href="<?php echo SITE_URL; ?>/bookings/" class="btn btn-sm btn-light">Alla bokningar</a>
                </div>
                <div class="card-body">
                    <?php if (empty($bookings)): ?>
                        <p class="text-muted">Du har inga kommande bokningar.</p>
                        <a href="<?php echo SITE_URL; ?>/bookings/new.php" class="btn btn-primary btn-sm">
                            <i class="fas fa-calendar-plus me-1"></i> Skapa bokning
                        </a>
                    <?php else: ?>
                        <div class="table-responsive">
                            <table class="table table-sm">
                                <thead>
                                    <tr>
                                        <th>Resurs</th>
                                        <th>Datum</th>
                                        <th>Tid</th>
                                        <th></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($bookings as $booking): ?>
                                        <tr>
                                            <td><?php echo $booking['resource_name']; ?></td>
                                            <td><?php echo formatDate($booking['start_time'], 'Y-m-d'); ?></td>
                                            <td>
                                                <?php echo formatDate($booking['start_time'], 'H:i'); ?> - 
                                                <?php echo formatDate($booking['end_time'], 'H:i'); ?>
                                            </td>
                                            <td>
                                                <a href="<?php echo SITE_URL; ?>/bookings/view.php?id=<?php echo $booking['booking_id']; ?>" class="btn btn-sm btn-outline-primary">
                                                    <i class="fas fa-eye"></i>
                                                </a>
                                                <a href="<?php echo SITE_URL; ?>/bookings/cancel.php?id=<?php echo $booking['booking_id']; ?>" class="btn btn-sm btn-outline-danger" data-confirm="Är du säker på att du vill avboka?">
                                                    <i class="fas fa-times"></i>
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                        <a href="<?php echo SITE_URL; ?>/bookings/new.php" class="btn btn-primary btn-sm mt-2">
                            <i class="fas fa-calendar-plus me-1"></i> Skapa bokning
                        </a>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- Aktuella ärenden -->
        <div class="col-md-6 mb-4">
            <div class="card shadow-sm h-100">
                <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
                    <h5 class="card-title mb-0">Mina ärenden</h5>
                    <a href="<?php echo SITE_URL; ?>/tickets/" class="btn btn-sm btn-light">Alla ärenden</a>
                </div>
                <div class="card-body">
                    <?php if (empty($tickets)): ?>
                        <p class="text-muted">Du har inga aktiva ärenden.</p>
                        <a href="<?php echo SITE_URL; ?>/tickets/new.php" class="btn btn-primary btn-sm">
                            <i class="fas fa-plus-circle me-1"></i> Skapa ärende
                        </a>
                    <?php else: ?>
                        <div class="table-responsive">
                            <table class="table table-sm">
                                <thead>
                                    <tr>
                                        <th>Ärende</th>
                                        <th>Status</th>
                                        <th>Skapad</th>
                                        <th></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($tickets as $ticket): ?>
                                        <tr>
                                            <td><?php echo $ticket['title']; ?></td>
                                            <td>
                                                <?php 
                                                    $statusClass = '';
                                                    switch ($ticket['status']) {
                                                        case 'new': 
                                                            $statusText = 'Ny';
                                                            $statusClass = 'badge bg-primary';
                                                            break;
                                                        case 'in_progress': 
                                                            $statusText = 'Pågående';
                                                            $statusClass = 'badge bg-info';
                                                            break;
                                                        case 'waiting': 
                                                            $statusText = 'Väntar';
                                                            $statusClass = 'badge bg-warning';
                                                            break;
                                                        case 'resolved': 
                                                            $statusText = 'Löst';
                                                            $statusClass = 'badge bg-success';
                                                            break;
                                                        default: 
                                                            $statusText = 'Stängd';
                                                            $statusClass = 'badge bg-secondary';
                                                    }
                                                ?>
                                                <span class="<?php echo $statusClass; ?>"><?php echo $statusText; ?></span>
                                            </td>
                                            <td><?php echo formatDate($ticket['created_at'], 'Y-m-d'); ?></td>
                                            <td>
                                                <a href="<?php echo SITE_URL; ?>/tickets/view.php?id=<?php echo $ticket['ticket_id']; ?>" class="btn btn-sm btn-outline-primary">
                                                    <i class="fas fa-eye"></i>
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                        <a href="<?php echo SITE_URL; ?>/tickets/new.php" class="btn btn-primary btn-sm mt-2">
                            <i class="fas fa-plus-circle me-1"></i> Skapa ärende
                        </a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <div class="row mb-4">
        <!-- Parkeringsköer -->
        <div class="col-md-6 mb-4">
            <div class="card shadow-sm h-100">
                <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
                    <h5 class="card-title mb-0">Parkeringsköer</h5>
                    <a href="<?php echo SITE_URL; ?>/parking/" class="btn btn-sm btn-light">Hantera köer</a>
                </div>
                <div class="card-body">
                    <?php if (empty($parkingQueues)): ?>
                        <p class="text-muted">Du står inte i någon parkeringskö.</p>
                        <a href="<?php echo SITE_URL; ?>/parking/queue.php" class="btn btn-primary btn-sm">
                            <i class="fas fa-car me-1"></i> Ställ dig i kö
                        </a>
                    <?php else: ?>
                        <div class="table-responsive">
                            <table class="table table-sm">
                                <thead>
                                    <tr>
                                        <th>Kö</th>
                                        <th>Din plats</th>
                                        <th>Registrerad</th>
                                        <th></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($parkingQueues as $queue): ?>
                                        <tr>
                                            <td><?php echo $queue['queue_name']; ?></td>
                                            <td><?php echo $queue['position_in_queue'] + 1; ?></td>
                                            <td><?php echo formatDate($queue['registration_date'], 'Y-m-d'); ?></td>
                                            <td>
                                                <a href="<?php echo SITE_URL; ?>/parking/leave_queue.php?id=<?php echo $queue['queue_id']; ?>" class="btn btn-sm btn-outline-danger" data-confirm="Är du säker på att du vill lämna denna kö?">
                                                    <i class="fas fa-sign-out-alt"></i>
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- Senaste nyheterna -->
        <div class="col-md-6 mb-4">
            <div class="card shadow-sm h-100">
                <div class="card-header bg-primary text-white">
                    <h5 class="card-title mb-0">Senaste nyheterna</h5>
                </div>
                <div class="card-body">
                    <?php if (empty($news)): ?>
                        <p class="text-muted">Det finns inga nyheter för närvarande.</p>
                    <?php else: ?>
                        <?php foreach ($news as $item): ?>
                            <div class="mb-3 <?php echo ($item['is_pinned'] ? 'border-start border-primary border-3 ps-3' : ''); ?>">
                                <h6><?php echo $item['title']; ?> <?php echo ($item['is_pinned'] ? '<span class="badge bg-primary">Fäst</span>' : ''); ?></h6>
                                <p class="text-muted small mb-1">
                                    Publicerad <?php echo formatDate($item['created_at'], 'd F Y'); ?>
                                </p>
                                <div class="news-content">
                                    <?php echo truncateString(nl2br($item['content']), 200); ?>
                                </div>
                            </div>
                            <?php if (!$loop->last): ?>
                                <hr>
                            <?php endif; ?>
                        <?php endforeach; ?>
                        <div class="text-center mt-3">
                            <a href="<?php echo SITE_URL; ?>/member/news.php" class="btn btn-outline-primary btn-sm">Läs alla nyheter</a>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
// Inkludera sidfot
include(TEMPLATES_PATH . '/footer.php');
?>