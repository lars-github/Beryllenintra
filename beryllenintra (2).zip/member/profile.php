<?php
/**
 * Profilsida för medlemmar i BRF Beryllen
 * 
 * Denna sida låter användare visa och redigera sina profiluppgifter
 */

// Initiera systemet
require_once('../init.php');

// Definiera en enkel User-klass för att ersätta den saknade klassen
class User {
    public function getUser($user_id) {
        global $db, $auth;
        
        // Använd $auth-objektet för att hämta grundläggande användardata
        $userData = $auth->getUserData();
        
        // Skapa ett grundläggande användardataobjekt som fallback
        $userDetails = [
            'user_id' => $userData['user_id'] ?? $user_id,
            'username' => $userData['username'] ?? '',
            'email' => $userData['email'] ?? '',
            'first_name' => $userData['first_name'] ?? '',
            'last_name' => $userData['last_name'] ?? '',
            'phone' => $userData['phone'] ?? '',
            'apartment_id' => $userData['apartment_id'] ?? null
        ];
        
        // Om telefonnummer finns i session, använd det (tillfällig lösning)
        if (isset($_SESSION['temp_phone'])) {
            $userDetails['phone'] = $_SESSION['temp_phone'];
        }
        
        // Om $db inte finns eller inte kan användas, returnera bara grundläggande data
        if (!isset($db) || !is_object($db)) {
            return $userDetails;
        }
        
        try {
            // Hämta användardata direkt
            $sql = "SELECT u.* FROM users u WHERE u.user_id = " . (int)$user_id;
            
            $result = $db->query($sql);
            
            // Hantera resultatet
            $user = null;
            if (is_object($result) && method_exists($result, 'fetch_assoc')) {
                $user = $result->fetch_assoc();
            } elseif (is_array($result) && !empty($result)) {
                $user = $result[0];
            }
            
            // Om vi har användardata, uppdatera våra grunddata
            if ($user) {
                foreach ($user as $key => $value) {
                    $userDetails[$key] = $value;
                }
                
                // Debug: Skriv ut användar-ID och apartment_id
                error_log("Användar-ID: " . $user_id . ", Lägenhet-ID: " . ($user['apartment_id'] ?? 'none'));
            }
            
            // Om användaren har en lägenhet, hämta lägenhetsinformation
            if (!empty($userDetails['apartment_id'])) {
                $aptSql = "SELECT * FROM apartments WHERE BrfNR = " . (int)$userDetails['apartment_id'];
                $aptResult = $db->query($aptSql);
                
                // Hantera resultatet
                $apartment = null;
                if (is_object($aptResult) && method_exists($aptResult, 'fetch_assoc')) {
                    $apartment = $aptResult->fetch_assoc();
                } elseif (is_array($aptResult) && !empty($aptResult)) {
                    $apartment = $aptResult[0];
                }
                
                // Om vi hittade lägenhetsdata, lägg till den i userDetails
                if ($apartment) {
                    foreach ($apartment as $key => $value) {
                        // Överför alla lägenhetsuppgifter till userDetails
                        $userDetails[$key] = $value;
                    }
                    
                    // Debug: Skriv ut hittad lägenhetsinformation
                    error_log("Lägenhetsdata hittad: BrfNR=" . ($apartment['BrfNR'] ?? 'none') . 
                             ", LantmNR=" . ($apartment['LantmNR'] ?? 'none') . 
                             ", Address=" . ($apartment['uppg'] ?? 'none'));
                } else {
                    error_log("Ingen lägenhetsinformation hittad för BrfNR=" . $userDetails['apartment_id']);
                }
                
                // Hämta ägarinformation
                $ownerSql = "SELECT * FROM ownership_history 
                             WHERE apartment_id = " . (int)$userDetails['apartment_id'] . " 
                             AND user_id = " . (int)$user_id . " 
                             AND end_date IS NULL";
                
                $ownerResult = $db->query($ownerSql);
                
                $ownerships = [];
                
                // Hantera resultatet
                if (is_object($ownerResult) && method_exists($ownerResult, 'fetch_all')) {
                    $ownerships = $ownerResult->fetch_all(MYSQLI_ASSOC);
                } elseif (is_object($ownerResult) && method_exists($ownerResult, 'fetch_assoc')) {
                    while ($row = $ownerResult->fetch_assoc()) {
                        $ownerships[] = $row;
                    }
                } elseif (is_array($ownerResult)) {
                    $ownerships = $ownerResult;
                }
                
                $userDetails['ownerships'] = $ownerships ?: [];
                
                // Debug: Antal ägardata hittade
                error_log("Antal ägardata hittade: " . count($userDetails['ownerships']));
            } else {
                error_log("Användaren har ingen kopplad lägenhet");
            }
            
        } catch (Exception $e) {
            error_log("Fel vid hämtning av användardata: " . $e->getMessage());
        }
        
        return $userDetails;
    }
    
    public function updateUser($user_id, $data) {
        global $db, $auth;
        
        $result = ['success' => false, 'message' => ''];
        
        // Om $db inte finns, kan vi inte uppdatera användaren
        if (!isset($db) || !is_object($db)) {
            $result['message'] = 'Databasanslutning saknas.';
            return $result;
        }
        
        try {
            // Bygg SQL-frågan manuellt utan parameterbindningar
            $fields = [];
            
            if (isset($data['first_name'])) {
                $fields[] = "first_name = '" . addslashes($data['first_name']) . "'";
            }
            
            if (isset($data['last_name'])) {
                $fields[] = "last_name = '" . addslashes($data['last_name']) . "'";
            }
            
            if (isset($data['email'])) {
                $fields[] = "email = '" . addslashes($data['email']) . "'";
            }
            
            if (isset($data['phone'])) {
                $fields[] = "phone = '" . addslashes($data['phone']) . "'";
            }
            
            if (isset($data['username'])) {
                $fields[] = "username = '" . addslashes($data['username']) . "'";
            }
            
            if (isset($data['password'])) {
                $hashedPassword = password_hash($data['password'], PASSWORD_DEFAULT);
                $fields[] = "password = '" . addslashes($hashedPassword) . "'";
            }
            
            if (empty($fields)) {
                // Inget att uppdatera
                $result['success'] = true;
                $result['message'] = 'Inget ändrades.';
                return $result;
            }
            
            $sql = "UPDATE users SET " . implode(", ", $fields) . " WHERE user_id = " . (int)$user_id;
            
            // Kör frågan direkt utan parametrar
            $success = $db->query($sql);
            
            if ($success) {
                // Försök logga aktiviteten
                try {
                    $currentUserId = $_SESSION['user_id'] ?? $user_id;
                    $ip = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
                    
                    $logQuery = "INSERT INTO activity_logs (user_id, action, entity_type, entity_id, description, ip_address) 
                                VALUES ('" . (int)$currentUserId . "', 'update', 'user', '" . (int)$user_id . "', 'Användare uppdaterad', '" . addslashes($ip) . "')";
                    
                    $db->query($logQuery);
                } catch (Exception $e) {
                    // Ignorera loggfel - de är inte kritiska
                }
                
                $result['success'] = true;
                $result['message'] = 'Användaruppgifter uppdaterade.';
            } else {
                $result['message'] = 'Ett fel uppstod vid uppdatering av användaren.';
            }
        } catch (Exception $e) {
            $result['message'] = 'Ett fel uppstod: ' . $e->getMessage();
        }
        
        return $result;
    }
}

// Kontrollera att användaren är inloggad
if (!$auth->isLoggedIn()) {
    $_SESSION['flash_message'] = 'Du måste vara inloggad för att se denna sida.';
    $_SESSION['flash_type'] = 'warning';
    redirect(SITE_URL . '/login.php');
}

// Hämta användardata
$userData = $auth->getUserData();
$user = new User();
$userDetails = $user->getUser($userData['user_id']);

// Spara telefonnummer i session om det kommer från formuläret
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['phone'])) {
    $_SESSION['temp_phone'] = $_POST['phone'];
}

// Om telefonnummer finns i session men inte i userDetails, lägg till det
if (empty($userDetails['phone']) && isset($_SESSION['temp_phone'])) {
    $userDetails['phone'] = $_SESSION['temp_phone'];
}

// Hantera formulärsändning
$success = false;
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Validera CSRF-token
    if (!validateCSRFToken($_POST['csrf_token'] ?? '')) {
        $error = 'Ogiltigt formulär. Försök igen.';
    } else {
        // Hämta och filtrera data
        $firstName = filterInput($_POST['first_name'] ?? '');
        $lastName = filterInput($_POST['last_name'] ?? '');
        $email = filterInput($_POST['email'] ?? '', 'email');
        $phone = filterInput($_POST['phone'] ?? '');
        $username = filterInput($_POST['username'] ?? '', 'email');
        $currentPassword = $_POST['current_password'] ?? '';
        $newPassword = $_POST['new_password'] ?? '';
        $confirmPassword = $_POST['confirm_password'] ?? '';
        
        // Bygg upp uppdateringsdata
        $updateData = [
            'first_name' => $firstName,
            'last_name' => $lastName,
            'email' => $email,
            'phone' => $phone,
            'username' => $username
        ];
        
        // Validera grundläggande data
        if (empty($firstName) || empty($lastName) || empty($email) || empty($username)) {
            $error = 'Du måste fylla i förnamn, efternamn, e-post och användarnamn.';
        } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $error = 'Ange en giltig e-postadress.';
        } elseif (!filter_var($username, FILTER_VALIDATE_EMAIL)) {
            $error = 'Användarnamnet måste vara en giltig e-postadress.';
        } else {
            // Kontrollera om lösenordet ska uppdateras
            if (!empty($newPassword)) {
                // Validera nuvarande lösenord
                $validPassword = password_verify($currentPassword, $userDetails['password']);
                
                if (!$validPassword) {
                    $error = 'Nuvarande lösenord är felaktigt.';
                } elseif (strlen($newPassword) < 6) {
                    $error = 'Lösenordet måste vara minst 6 tecken långt.';
                } elseif ($newPassword !== $confirmPassword) {
                    $error = 'De nya lösenorden matchar inte.';
                } else {
                    $updateData['password'] = $newPassword;
                }
            }
            
            // Om inga fel uppstod, uppdatera användaren
            if (empty($error)) {
                $result = $user->updateUser($userData['user_id'], $updateData);
                
                if ($result['success']) {
                    $success = true;
                    $_SESSION['flash_message'] = 'Dina profiluppgifter har uppdaterats.';
                    $_SESSION['flash_type'] = 'success';
                    
                    // Spara telefonnummer i session innan omdirigering
                    $_SESSION['temp_phone'] = $phone;
                    
                    // Uppdatera session-data (men skippa omdirigering tills vidare)
                    // redirect(SITE_URL . '/member/profile.php');
                    
                    // Återladda sidan istället för omdirigering för att bevara data
                    $userDetails = $user->getUser($userData['user_id']);
                } else {
                    $error = $result['message'];
                }
            }
        }
    }
}

// Sidspecifika inställningar
$pageTitle = 'Min profil';
$pageDescription = 'Redigera dina profiluppgifter';

// Inkludera sidhuvud
include(TEMPLATES_PATH . '/header.php');
?>

<div class="container py-4">
    <div class="row mb-4">
        <div class="col-12">
            <h1>Min profil</h1>
            <p class="lead">
                Här kan du se och uppdatera dina personuppgifter.
                <span class="text-muted ms-2" style="font-size: 0.85em;">* Fält markerade med asterisk är obligatoriska.</span>
            </p>
        </div>
    </div>

    <div class="row">
        <div class="col-md-6 mb-4">
            <!-- Profilformulär -->
            <div class="card shadow-sm">
                <div class="card-header bg-primary text-white">
                    <h5 class="card-title mb-0">Personuppgifter</h5>
                </div>
                <div class="card-body">
                    <?php if ($success): ?>
                        <div class="alert alert-success">
                            Dina profiluppgifter har uppdaterats.
                        </div>
                    <?php endif; ?>

                    <?php if (!empty($error)): ?>
                        <div class="alert alert-danger">
                            <?php echo $error; ?>
                        </div>
                    <?php endif; ?>

                    <form method="post" action="">
                        <input type="hidden" name="csrf_token" value="<?php echo generateCSRFToken(); ?>">
                        
                        <div class="mb-3">
                            <label for="first_name" class="form-label">Förnamn *</label>
                            <input type="text" class="form-control" id="first_name" name="first_name" value="<?php echo isset($userDetails['first_name']) ? $userDetails['first_name'] : ''; ?>" required>
                        </div>
                        
                        <div class="mb-3">
                            <label for="last_name" class="form-label">Efternamn *</label>
                            <input type="text" class="form-control" id="last_name" name="last_name" value="<?php echo isset($userDetails['last_name']) ? $userDetails['last_name'] : ''; ?>" required>
                        </div>
                        
                        <div class="mb-3">
                            <label for="email" class="form-label">E-post *</label>
                            <input type="email" class="form-control" id="email" name="email" value="<?php echo isset($userDetails['email']) ? $userDetails['email'] : ''; ?>" required>
                        </div>
                        
                        <div class="mb-3">
                            <label for="phone" class="form-label">Telefon</label>
                            <input type="tel" class="form-control" id="phone" name="phone" value="<?php echo isset($userDetails['phone']) ? $userDetails['phone'] : ''; ?>">
                        </div>
                        
                        <div class="mb-3">
                            <label for="username" class="form-label">Användarnamn (=epostadress) *</label>
                            <input type="text" class="form-control" id="username" name="username" value="<?php echo isset($userDetails['username']) ? $userDetails['username'] : ''; ?>" required>
                            <div class="form-text">Användarnamnet används för inloggning och ska vara din e-postadress.</div>
                        </div>
                        
                        <button type="submit" class="btn btn-primary">Spara ändringar</button>
                    </form>
                </div>
            </div>
        </div>
        
        <div class="col-md-6 mb-4">
            <!-- Lägenhetsinformation -->
            <div class="card shadow-sm">
                <div class="card-header bg-primary text-white">
                    <h5 class="card-title mb-0">Min lägenhet</h5>
                </div>
                <div class="card-body">
                    <?php if (!empty($userDetails['apartment_id'])): ?>
                        <div class="row">
                            <div class="col-sm-4">
                                <strong>Lägenhetsnr:</strong>
                            </div>
                            <div class="col-sm-8">
                                <?php echo isset($userDetails['apartment_id']) ? $userDetails['apartment_id'] : $userDetails['BrfNR']; ?>
                                (Lantm. nr: <?php echo isset($userDetails['LantmNR']) ? $userDetails['LantmNR'] : '(Saknas)'; ?>)
                            </div>
                        </div>
                        <div class="row mt-2">
                            <div class="col-sm-4">
                                <strong>Adress:</strong>
                            </div>
                            <div class="col-sm-8">
                                <?php echo isset($userDetails['uppg']) ? $userDetails['uppg'] : '(Saknas)'; ?>, 
                                vån <?php echo isset($userDetails['floor']) ? $userDetails['floor'] : '(Saknas)'; ?>
                            </div>
                        </div>
                        <div class="row mt-2">
                            <div class="col-sm-4">
                                <strong>Storlek:</strong>
                            </div>
                            <div class="col-sm-8">
                                <?php echo isset($userDetails['area']) ? $userDetails['area'] : '(Saknas)'; ?> m²
                            </div>
                        </div>
                        
                        <?php if (!empty($userDetails['ownerships'])): ?>
                            <hr>
                            <h6>Ägarinformation</h6>
                            <?php foreach ($userDetails['ownerships'] as $ownership): ?>
                                <div class="row mt-2">
                                    <div class="col-sm-4">
                                        <strong>Andel:</strong>
                                    </div>
                                    <div class="col-sm-8">
                                        <?php echo isset($ownership['share_percentage']) ? number_format($ownership['share_percentage'], 1) : ''; ?>%
                                    </div>
                                </div>
                                <div class="row mt-2">
                                    <div class="col-sm-4">
                                        <strong>Sedan:</strong>
                                    </div>
                                    <div class="col-sm-8">
                                        <?php echo isset($ownership['start_date']) ? formatDate($ownership['start_date'], 'Y-m-d') : ''; ?>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        <?php endif; ?>
                        
                        <div class="mt-3 text-muted">
                            <small>Om uppgifterna behöver uppdateras, kontakta styrelsen.</small>
                        </div>
                    <?php else: ?>
                        <p class="text-muted">Ingen lägenhet är kopplad till ditt konto.</p>
                        <p>Om du är medlem i föreningen, kontakta styrelsen för att koppla din lägenhet till ditt konto.</p>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Lösenordsformulär -->
            <div class="card shadow-sm mt-4">
                <div class="card-header bg-primary text-white">
                    <h5 class="card-title mb-0">Ändra lösenord</h5>
                </div>
                <div class="card-body">
                    <form method="post" action="">
                        <input type="hidden" name="csrf_token" value="<?php echo generateCSRFToken(); ?>">
                        <input type="hidden" name="first_name" value="<?php echo isset($userDetails['first_name']) ? $userDetails['first_name'] : ''; ?>">
                        <input type="hidden" name="last_name" value="<?php echo isset($userDetails['last_name']) ? $userDetails['last_name'] : ''; ?>">
                        <input type="hidden" name="email" value="<?php echo isset($userDetails['email']) ? $userDetails['email'] : ''; ?>">
                        <input type="hidden" name="phone" value="<?php echo isset($userDetails['phone']) ? $userDetails['phone'] : ''; ?>">
                        <input type="hidden" name="username" value="<?php echo isset($userDetails['username']) ? $userDetails['username'] : ''; ?>">
                        
                        <div class="mb-3">
                            <label for="current_password" class="form-label">Nuvarande lösenord *</label>
                            <input type="password" class="form-control" id="current_password" name="current_password" required>
                        </div>
                        
                        <div class="mb-3">
                            <label for="new_password" class="form-label">Nytt lösenord *</label>
                            <input type="password" class="form-control" id="new_password" name="new_password" required>
                            <div class="form-text">Minst 6 tecken långt.</div>
                        </div>
                        
                        <div class="mb-3">
                            <label for="confirm_password" class="form-label">Bekräfta nytt lösenord *</label>
                            <input type="password" class="form-control" id="confirm_password" name="confirm_password" required>
                        </div>
                        
                        <button type="submit" class="btn btn-primary">Ändra lösenord</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const emailField = document.getElementById('email');
    const usernameField = document.getElementById('username');
    
    // Synkronisera fälten när epost ändras
    emailField.addEventListener('input', function() {
        usernameField.value = this.value;
    });
    
    // Förhindra manuell inmatning i användarnamn-fältet
    usernameField.addEventListener('keydown', function(e) {
        e.preventDefault();
        return false;
    });
    
    // Förhindra copy-paste i användarnamn-fältet
    usernameField.addEventListener('paste', function(e) {
        e.preventDefault();
        return false;
    });
    
    // Förhindra redigering via kontextmeny
    usernameField.addEventListener('contextmenu', function(e) {
        e.preventDefault();
        return false;
    });
});
</script>

<?php
// Inkludera sidfot
include(TEMPLATES_PATH . '/footer.php');
?>