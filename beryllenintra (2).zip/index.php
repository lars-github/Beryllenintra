<?php
/**
 * Startsida för BRF Beryllen
 * 
 * Denna sida visar startsidan för intranätet
 */

// Initiera systemet
require_once('init.php');

// Hämta nyheter
$db = Database::getInstance();
$news = $db->getRows(
    "SELECT n.*, u.first_name, u.last_name 
    FROM news n
    LEFT JOIN users u ON n.created_by = u.user_id
    WHERE n.visibility = 'public' OR (n.visibility = 'member' AND ?)
    ORDER BY n.is_pinned DESC, n.created_at DESC
    LIMIT 5",
    [$auth->isLoggedIn()]
);

// Sidspecifika inställningar
$pageTitle = 'Välkommen';
$pageDescription = 'Välkommen till BRF Beryllens webbplats';

// Inkludera sidhuvud
include(TEMPLATES_PATH . '/header.php');
?>

<div class="row mb-4">
    <div class="col-md-8">
        <div class="card shadow-sm h-100">
            <div class="card-body">
                <h1 class="card-title">Välkommen till BRF Beryllen</h1>
                <p class="lead">
                    Bostadsrättsföreningen Beryllen ligger i centrala Göteborg och består av 240 lägenheter på Bohusgatan 6-26. 
                    Föreningen bildades 2009 och har en engagerad styrelse som arbetar för att göra boendet så trivsamt som möjligt.
                </p>
                <p>
                    På vår webbplats hittar du information om föreningen, nyheter, kontaktuppgifter och 
                    <?php if ($auth->isLoggedIn()): ?>
                        tillgång till medlemssidor med dokument, bokningssystem och mycket mer.
                    <?php else: ?>
                        information om hur du kommer i kontakt med styrelsen.
                    <?php endif; ?>
                </p>
                
                <?php if (!$auth->isLoggedIn()): ?>
                <div class="mt-4">
                    <a href="<?php echo SITE_URL; ?>/login.php" class="btn btn-primary">Logga in på medlemssidorna</a>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <div class="col-md-4">
        <div class="card shadow-sm h-100">
            <div class="card-header bg-primary text-white">
                <h5 class="card-title mb-0">Kontaktuppgifter</h5>
            </div>
            <div class="card-body">
                <address>
                    <strong>BRF Beryllen</strong><br>
                    Bohusgatan 6-26<br>
                    411 39 Göteborg<br><br>
                    <?php if (!empty($siteSettings['contact_phone'])): ?>
                        <i class="fas fa-phone me-1"></i> <?php echo $siteSettings['contact_phone']; ?><br>
                    <?php endif; ?>
                    <i class="fas fa-envelope me-1"></i> <a href="mailto:<?php echo $siteSettings['email']; ?>"><?php echo $siteSettings['email']; ?></a>
                </address>
                
                <hr>
                
                <h6>Felanmälan</h6>
                <p>Vid akuta fel under icke kontorstid, ring jouren:</p>
                <p class="mb-0"><strong>Tel:</strong> 031-123 45 67</p>
            </div>
        </div>
    </div>
</div>

<!-- Nyheter -->
<div class="row">
    <div class="col-12">
        <div class="card shadow-sm">
            <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
                <h5 class="card-title mb-0">Nyheter</h5>
                <?php if ($auth->hasRole('admin')): ?>
                <a href="<?php echo SITE_URL; ?>/admin/news.php" class="btn btn-sm btn-light">Hantera nyheter</a>
                <?php endif; ?>
            </div>
            <div class="card-body">
                <?php if (empty($news)): ?>
                    <p class="text-muted">Inga nyheter att visa.</p>
                <?php else: ?>
                    <?php foreach ($news as $item): ?>
                        <div class="news-item mb-4 pb-3 <?php echo ($item['is_pinned'] ? 'border-start border-primary border-3 ps-3' : ''); ?>">
                            <h4><?php echo $item['title']; ?> <?php echo ($item['is_pinned'] ? '<span class="badge bg-primary">Fäst</span>' : ''); ?></h4>
                            <p class="text-muted small mb-2">
                                Publicerad <?php echo formatDate($item['created_at'], 'd F Y'); ?> 
                                <?php if ($item['created_by']): ?>
                                av <?php echo $item['first_name'] . ' ' . $item['last_name']; ?>
                                <?php endif; ?>
                            </p>
                            <div class="news-content">
                                <?php echo nl2br($item['content']); ?>
                            </div>
                        </div>
                        <?php if (!$loop->last): ?>
                            <hr>
                        <?php endif; ?>
                    <?php endforeach; ?>
                    
                    <?php if (count($news) >= 5): ?>
                        <div class="text-center mt-3">
                            <a href="<?php echo SITE_URL; ?>/news.php" class="btn btn-outline-primary">Visa fler nyheter</a>
                        </div>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<?php
// Inkludera sidfot
include(TEMPLATES_PATH . '/footer.php');
?>