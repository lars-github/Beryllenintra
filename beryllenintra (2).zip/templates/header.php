<?php
/**
 * Sidhuvud för BRF Beryllen
 * 
 * Denna fil innehåller sidhuvudet som inkluderas på alla sidor
 */

// Förhindra direkt åtkomst till denna fil
if (!defined('ACCESS_ALLOWED')) {
    header('HTTP/1.0 403 Forbidden');
    exit;
}

// Hämta titel och beskrivning från parametrar eller använd standard
$pageTitle = isset($pageTitle) ? $pageTitle . ' - ' . $siteSettings['title'] : $siteSettings['title'];
$pageDescription = isset($pageDescription) ? $pageDescription : $siteSettings['description'];
?>
<!DOCTYPE html>
<html lang="sv">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="<?php echo $pageDescription; ?>">
    <title><?php echo $pageTitle; ?></title>
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Font Awesome ikoner -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    
    <!-- Custom CSS -->
    <link rel="stylesheet" href="<?php echo SITE_URL; ?>/public/css/style.css">
    
    <?php if (isset($extraCSS)): ?>
        <?php foreach($extraCSS as $css): ?>
            <link rel="stylesheet" href="<?php echo SITE_URL . $css; ?>">
        <?php endforeach; ?>
    <?php endif; ?>
</head>
<body>

<header>
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container">
            <a class="navbar-brand" href="<?php echo SITE_URL; ?>">
                <img src="<?php echo SITE_URL; ?>/public/img/logo.png" alt="BRF Beryllen" width="30" height="30" class="d-inline-block align-top">
                BRF Beryllen
            </a>
            
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarMain">
                <span class="navbar-toggler-icon"></span>
            </button>
            
            <div class="collapse navbar-collapse" id="navbarMain">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo SITE_URL; ?>">Hem</a>
                    </li>
                    
                    <?php if ($auth->isLoggedIn()): ?>
                        <?php if ($auth->hasRole('member')): ?>
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo SITE_URL; ?>/member/">Medlemssidor</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo SITE_URL; ?>/bookings/">Bokningar</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo SITE_URL; ?>/tickets/">Ärenden</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo SITE_URL; ?>/documents/">Dokument</a>
                            </li>
                        <?php endif; ?>
                        
                        <?php if ($auth->hasRole('admin')): ?>
                            <li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle" href="#" id="adminDropdown" role="button" data-bs-toggle="dropdown">
                                    Administration
                                </a>
                                <ul class="dropdown-menu">
                                    <li><a class="dropdown-item" href="<?php echo SITE_URL; ?>/admin/">Dashboard</a></li>
                                    <li><a class="dropdown-item" href="<?php echo SITE_URL; ?>/admin/users.php">Användare</a></li>
                                    <li><a class="dropdown-item" href="<?php echo SITE_URL; ?>/admin/news.php">Nyheter</a></li>
                                    <li><a class="dropdown-item" href="<?php echo SITE_URL; ?>/admin/tickets.php">Ärenden</a></li>
                                    <li><a class="dropdown-item" href="<?php echo SITE_URL; ?>/admin/bookings.php">Bokningar</a></li>
                                </ul>
                            </li>
                        <?php endif; ?>
                        
                        <?php if ($auth->hasRole('superadmin')): ?>
                            <li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle" href="#" id="superadminDropdown" role="button" data-bs-toggle="dropdown">
                                    Systemadmin
                                </a>
                                <ul class="dropdown-menu">
                                    <li><a class="dropdown-item" href="<?php echo SITE_URL; ?>/admin/apartments.php">Lägenheter</a></li>
                                    <li><a class="dropdown-item" href="<?php echo SITE_URL; ?>/admin/parking.php">Parkering</a></li>
                                    <li><a class="dropdown-item" href="<?php echo SITE_URL; ?>/admin/config.php">Inställningar</a></li>
                                    <li><a class="dropdown-item" href="<?php echo SITE_URL; ?>/admin/logs.php">Loggar</a></li>
                                </ul>
                            </li>
                        <?php endif; ?>
                    <?php endif; ?>
                </ul>
                
                <ul class="navbar-nav ms-auto">
                    <?php if ($auth->isLoggedIn()): ?>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-bs-toggle="dropdown">
                                <i class="fas fa-user"></i> <?php echo $auth->getUserData()['first_name']; ?>
                            </a>
                            <ul class="dropdown-menu dropdown-menu-end">
                                <li><a class="dropdown-item" href="<?php echo SITE_URL; ?>/member/profile.php">Min profil</a></li>
                                <li><hr class="dropdown-divider"></li>
                                <li><a class="dropdown-item" href="<?php echo SITE_URL; ?>/logout.php">Logga ut</a></li>
                            </ul>
                        </li>
                    <?php else: ?>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo SITE_URL; ?>/login.php">Logga in</a>
                        </li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </nav>
</header>

<main class="container py-4">
    <?php if (isset($_SESSION['flash_message'])): ?>
        <div class="alert alert-<?php echo $_SESSION['flash_type'] ?? 'info'; ?> alert-dismissible fade show">
            <?php echo $_SESSION['flash_message']; ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <?php unset($_SESSION['flash_message'], $_SESSION['flash_type']); ?>
    <?php endif; ?>