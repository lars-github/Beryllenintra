<?php
/**
 * Sidfot för BRF Beryllen
 * 
 * Denna fil innehåller sidfoten som inkluderas på alla sidor
 */

// Förhindra direkt åtkomst till denna fil
if (!defined('ACCESS_ALLOWED')) {
    header('HTTP/1.0 403 Forbidden');
    exit;
}
?>
</main>

<footer class="bg-light py-4 mt-5 border-top">
    <div class="container">
        <div class="row">
            <div class="col-md-4">
                <h5>BRF Beryllen</h5>
                <address class="mb-3">
                    Bohusgatan 6-26<br>
                    411 39 Göteborg<br>
                    <?php if (!empty($siteSettings['contact_phone'])): ?>
                        <i class="fas fa-phone me-1"></i> <?php echo $siteSettings['contact_phone']; ?><br>
                    <?php endif; ?>
                    <i class="fas fa-envelope me-1"></i> <a href="mailto:<?php echo $siteSettings['email']; ?>"><?php echo $siteSettings['email']; ?></a>
                </address>
            </div>
            <div class="col-md-4">
                <h5>Snabblänkar</h5>
                <ul class="list-unstyled">
                    <li><a href="<?php echo SITE_URL; ?>">Hem</a></li>
                    <li><a href="<?php echo SITE_URL; ?>/contact.php">Kontakt</a></li>
                    <?php if ($auth->isLoggedIn()): ?>
                        <li><a href="<?php echo SITE_URL; ?>/member/">Medlemssidor</a></li>
                        <li><a href="<?php echo SITE_URL; ?>/bookings/">Bokningar</a></li>
                        <li><a href="<?php echo SITE_URL; ?>/documents/">Dokument</a></li>
                    <?php endif; ?>
                </ul>
            </div>
            <div class="col-md-4">
                <h5>Allmän information</h5>
                <p>Bostadsrättsföreningen Beryllen är en förening med 240 lägenheter i centrala Göteborg.</p>
                <p class="small">© <?php echo date('Y'); ?> BRF Beryllen. Alla rättigheter förbehållna.</p>
            </div>
        </div>
    </div>
</footer>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>

<!-- Custom JavaScript -->
<script src="<?php echo SITE_URL; ?>/public/js/main.js"></script>

<?php if (isset($extraJS)): ?>
    <?php foreach($extraJS as $js): ?>
        <script src="<?php echo SITE_URL . $js; ?>"></script>
    <?php endforeach; ?>
<?php endif; ?>

</body>
</html>