# BRF Beryllen Intranät

Ett intranät för BRF Beryllen med funktioner för medlemmar, administration och styrelse.

## Funktioner

* **Medlemshantering:** Registrering, inloggning och profilhantering för boende
* **Lägenhetsinformation:** Koppling mellan användare och lägenheter
* **Bokningssystem:** För tvättstugor, bastu, gästrum, etc.
* **Ärendehantering:** För felanmälningar, förslag och frågor
* **Parkeringsköer:** Hantering av köer till olika typer av parkeringsplatser
* **Dokumenthantering:** För styrelse- och föreningsdokument
* **Nyheter:** För att informera medlemmar om aktuella händelser
* **Administration:** Verktyg för styrelse och administratörer

## Teknisk struktur

Projektet är byggt med följande teknologier:

* **Backend:** PHP
* **Databas:** MySQL
* **Frontend:** HTML5, CSS3, JavaScript, Bootstrap 5
* **Filstruktur:** MVC-inspirerad med tydlig separation av logik

## Installation

1. Skapa en databas på webbhotellet
2. Importera `create_database.sql` för att skapa tabellstrukturen
3. Konfigurera databaskopplingen i `config/database.php`
4. Ladda upp filerna till webbhotellet
5. Logga in med det fördefinierade admin-kontot:
   * Användarnamn: `admin`
   * Lösenord: `admin123` (ändra omedelbart efter första inloggning!)

## Filstruktur

```
/brf-intranat/
│
├── admin/              - Administrativa sidor
├── assets/             - Uppladdade filer
├── bookings/           - Bokningssystem
├── config/             - Konfigurationsfiler
├── documents/          - Dokumenthantering
├── includes/           - Gemensamma funktioner och klasser
│   ├── classes/        - PHP-klasser
│   └── functions.php   - Hjälpfunktioner
├── logs/               - Loggfiler
├── member/             - Medlemssidor
├── parking/            - Parkeringshantering
├── public/             - Publika resurser
│   ├── css/            - Stilmallar
│   ├── img/            - Bilder
│   └── js/             - JavaScript
├── templates/          - HTML-mallar
├── tickets/            - Ärendehantering
├── uploads/            - Uppladdade bilagor
├── index.php           - Startsida
├── login.php           - Inloggningssida
└── logout.php          - Utloggning
```

## Anpassning

### För andra bostadsrättsföreningar

Systemet är designat för att enkelt kunna anpassas till andra bostadsrättsföreningar:

1. Uppdatera föreningsspecifik information i `config/config.php`
2. Importera era lägenheter i `apartments`-tabellen
3. Konfigurera bokningsbara resurser i `resources`-tabellen
4. Anpassa navigationsmenyerna i `templates/header.php`

## Utveckling och underhåll

### Utvecklingsmiljö

1. Klona repot: `git clone https://github.com/username/brf-intranat.git`
2. Konfigurera en lokal LAMP/WAMP-miljö
3. Uppdatera databaskonfigurationen i `config/database.php`
4. Navigera till `http://localhost/brf-intranat/`

### Modulärt system

Nya moduler kan enkelt läggas till genom att:

1. Skapa en ny mapp för modulen
2. Lägg till nödvändiga PHP-filer
3. Skapa en ny klass i `includes/classes/` för modullogik
4. Uppdatera navigationsmenyn i `templates/header.php`

## Säkerhet

* Använder parametriserade SQL-frågor för att förhindra SQL-injektion
* CSRF-skydd för alla formulär
* Hashar lösenord med PHP:s password_hash/password_verify
* Loggar alla viktiga aktiviteter i `activity_logs`-tabellen

## Licens

Detta projekt är skapat för BRF Beryllen och får inte användas eller spridas utan tillstånd.