# Installationsguide för BRF Beryllen Intranät

Denna guide beskriver steg för steg hur du installerar och konfigurerar intranätet på ett webbhotell.

## Förutsättningar

* Ett webbhotell med stöd för:
  * PHP 7.4 eller senare
  * MySQL 5.7 eller senare
  * PHPMyAdmin eller liknande för databashantering
* Tillgång till webbhotellets kontrollpanel
* FTP-klient för filöverföring (t.ex. FileZilla)

## Steg 1: Förbered databasen

1. Logga in på webbhotellets kontrollpanel
2. Gå till databashanteringen (oftast PHPMyAdmin)
3. Skapa en ny databas (eller använd en befintlig)
4. Anteckna databasnamn, användarnamn och lösenord

## Steg 2: Importera databasstrukturen

1. I PHPMyAdmin, välj din databas
2. Klicka på fliken "Import"
3. Ladda upp filen `create_database.sql`
4. Klicka på "Go" eller "Kör" för att importera strukturen
5. Kontrollera att tabellerna har skapats korrekt
6. Om du har äldre data att migrera, kör även `migrate_members_data.sql` efter anpassning

## Steg 3: Ladda upp filerna

1. Öppna din FTP-klient
2. Anslut till webbhotellet med dina inloggningsuppgifter
3. Navigera till webbplatsens rot eller önskad katalog
4. Ladda upp alla filer och mappar från projektet
5. Säkerställ att filrättigheterna är korrekt inställda:
   * Alla kataloger: 755 (drwxr-xr-x)
   * Alla filer: 644 (rw-r--r--)
   * Skriv- och uppladdningskataloger (logs, uploads): 777 (drwxrwxrwx)

## Steg 4: Konfigurera systemet

1. Öppna filen `config/database.php`
2. Uppdatera databasanslutningsparametrarna:
   ```php
   define('DB_HOST', 'din_databasserver');
   define('DB_USER', 'ditt_databasanvändarnamn');
   define('DB_PASS', 'ditt_databaslösenord');
   define('DB_NAME', 'ditt_databasnamn');
   ```

3. Öppna filen `config/config.php`
4. Uppdatera webbplatsens URL och andra inställningar:
   ```php
   define('SITE_URL', 'https://www.dindomän.se/intranät');
   define('SITE_TITLE', 'Din BRF - Intranät');
   ```

## Steg 5: Ladda upp lägenhetsdata och medlemsinformation

För en ny installation, använd något av dessa tillvägagångssätt:

### Alternativ 1: Manuell inmatning via admin-gränssnittet
1. Logga in med det fördefinierade admin-kontot:
   * Användarnamn: `admin`
   * Lösenord: `admin123`
2. Gå till Admin > Lägenheter
3. Lägg till lägenheter manuellt

### Alternativ 2: Anpassa och använd importfunktionen
1. Formatera din lägenhetsdata i CSV-format enligt mallen
2. Logga in som superadmin och använd importfunktionen

### Alternativ 3: Direkt databasimport
1. Formatera din data i SQL-format
2. Importera via PHPMyAdmin

## Steg 6: Initiala inställningar

1. Logga in som superadmin
2. Gå till Admin > Inställningar
3. Konfigurera systemets grundläggande inställningar:
   * Föreningens kontaktuppgifter
   * E-postinställningar
   * Bokningssystemets parametrar
   * Säkerhetsinställningar

4. Gå till Admin > Användare
5. Ändra superadmin-lösenordet (viktigt!)
6. Skapa ytterligare administratörskonton vid behov

## Steg 7: Konfigurera bokningsbara resurser

1. Gå till Admin > Bokningar > Resurser
2. Lägg till de resurser som ska vara bokningsbara:
   * Tvättstugor
   * Bastu
   * Gästrum
   * Hobbyrum
   * Festlokal
   * etc.

3. Ställ in tidsbegränsningar och regler för varje resurs

## Steg 8: Konfigurera parkeringsköer

1. Gå till Admin > Parkering > Köer
2. Verifiera att de fördefinierade köerna motsvarar föreningens behov
3. Lägg till eller ta bort köer efter behov
4. Konfigurera parkeringsplatser och koppla dem till rätt kötyp

## Steg 9: Testa systemet

1. Testa inloggning
2. Testa bokningssystemet
3. Testa ärendehanteringen
4. Säkerställ att e-postaviseringar fungerar

## Felsökning

### Databasanslutningsproblem
* Kontrollera att databasuppgifterna i `config/database.php` är korrekta
* Verifiera att databasen är tillgänglig och att användaren har rätt behörigheter

### Visningsproblem
* Kontrollera att `SITE_URL` är korrekt inställd i `config/config.php`
* Verifiera att alla filer har laddats upp korrekt
* Kontrollera att webbservern kan köra PHP-filer

### Loggning
* Se efter felmeddelanden i `logs/`-katalogen
* Aktivera PHP-felrapportering i utvecklingsmiljön genom att ändra i `config/config.php`:
  ```php
  ini_set('display_errors', 1); // Sätt till 1 under utveckling, 0 i produktion
  ```

## Support

Om du behöver hjälp, kontakta systemadministratören eller utvecklaren för support.