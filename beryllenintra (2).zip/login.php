<?php
/**
 * Inloggningssida för BRF Beryllen
 * 
 * Denna sida låter användare logga in på systemet
 */

// Initiera systemet
require_once('init.php');

// Om användaren redan är inloggad, omdirigera till medlemssidor
if ($auth->isLoggedIn()) {
    if ($auth->hasRole('admin')) {
        redirect(SITE_URL . '/admin/');
    } else {
        redirect(SITE_URL . '/member/');
    }
}

// Hantera inloggningsförsök
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Validera CSRF-token
    if (!validateCSRFToken($_POST['csrf_token'] ?? '')) {
        $error = 'Ogiltigt formulär. Försök igen.';
    } else {
        $username = filterInput($_POST['username'] ?? '');
        $password = $_POST['password'] ?? '';
        
        if (empty($username) || empty($password)) {
            $error = 'Du måste ange både användarnamn och lösenord.';
        } else {
            // Försök logga in
            if ($auth->login($username, $password)) {
                // Omdirigera baserat på användarroll
                if ($auth->hasRole('admin')) {
                    redirect(SITE_URL . '/admin/');
                } else {
                    redirect(SITE_URL . '/member/');
                }
            } else {
                $error = 'Fel användarnamn eller lösenord.';
            }
        }
    }
}

// Sidspecifika inställningar
$pageTitle = 'Logga in';
$pageDescription = 'Logga in på BRF Beryllens medlemssidor';

// Inkludera sidhuvud
include(TEMPLATES_PATH . '/header.php');
?>

<div class="row justify-content-center my-5">
    <div class="col-md-6 col-lg-5">
        <div class="card shadow">
            <div class="card-header bg-primary text-white">
                <h4 class="card-title mb-0">Logga in på medlemssidorna</h4>
            </div>
            <div class="card-body">
                <?php if (!empty($error)): ?>
                    <div class="alert alert-danger"><?php echo $error; ?></div>
                <?php endif; ?>
                
                <form method="post" action="">
                    <input type="hidden" name="csrf_token" value="<?php echo generateCSRFToken(); ?>">
                    
                    <div class="mb-3">
                        <label for="username" class="form-label">E-post eller användarnamn</label>
                        <input type="text" class="form-control" id="username" name="username" required autofocus>
                    </div>
                    
                    <div class="mb-3">
                        <label for="password" class="form-label">Lösenord</label>
                        <input type="password" class="form-control" id="password" name="password" required>
                    </div>
                    
                    <div class="d-grid">
                        <button type="submit" class="btn btn-primary">Logga in</button>
                    </div>
                </form>
                
                <div class="mt-3 text-center">
                    <a href="<?php echo SITE_URL; ?>/forgot-password.php">Glömt lösenord?</a>
                </div>
            </div>
        </div>
        
        <div class="card mt-3">
            <div class="card-body">
                <h5>Information</h5>
                <p>För att få tillgång till medlemssidorna behöver du vara medlem i Brf Beryllen. Kontakta styrelsen om du behöver hjälp med inloggningsuppgifter.</p>
            </div>
        </div>
    </div>
</div>

<?php
// Inkludera sidfot
include(TEMPLATES_PATH . '/footer.php');
?>