<?php
/**
 * Database Class
 * 
 * En klass för att hantera databasanslutningar och frågor
 * Använder mysqli som databasanslutning
 */
class Database {
    // Privata egenskaper
    private $connection;
    private static $instance = null;
    
    /**
     * Private konstruktor för att förhindra direkt instansiering
     * Använder Singleton-designmönster
     */
    private function __construct() {
        // Definiera åtkomst för att inkludera konfigurationsfilen
        if (!defined('ACCESS_ALLOWED')) {
            define('ACCESS_ALLOWED', true);
        }
        
        // Inkludera konfigurationsfilerna om de inte redan är inkluderade
        if (!defined('DB_HOST')) {
            require_once(realpath(dirname(__FILE__) . '/../../config/database.php'));
        }
        
        // Skapa databasanslutning
        $this->connection = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
        
        // Kontrollera anslutningen
        if ($this->connection->connect_error) {
            $this->logError("Anslutning misslyckades: " . $this->connection->connect_error);
            die("Anslutning misslyckades: " . $this->connection->connect_error);
        }
        
        // Sätt teckenkodning
        $this->connection->set_charset(DB_CHARSET);
    }
    
    /**
     * Singleton-metod för att få en databasinstans
     * 
     * @return Database Den enda databasinstansen
     */
    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new Database();
        }
        return self::$instance;
    }
    
    /**
     * Förbered och kör en förberedd SQL-fråga
     * 
     * @param string $query SQL-fråga med platshållare
     * @param array $params Parametrar för frågan
     * @return mysqli_stmt|bool Förberedda frågan eller false vid fel
     */
    public function prepareAndExecute($query, $params = []) {
        $stmt = $this->connection->prepare($query);
        
        if (!$stmt) {
            $this->logError("Fel vid förberedelse av fråga: " . $this->connection->error . " för frågan: " . $query);
            return false;
        }
        
        // Binda parametrar om det finns några
        if (!empty($params)) {
            // Skapa types-strängen (i = integer, d = double, s = string, b = blob)
            $types = '';
            foreach ($params as $param) {
                if (is_int($param)) {
                    $types .= 'i';
                } elseif (is_float($param)) {
                    $types .= 'd';
                } elseif (is_string($param)) {
                    $types .= 's';
                } else {
                    $types .= 'b'; // Behandla allt annat som blob
                }
            }
            
            // Binda parametrar
            $bindParams = array_merge([$types], $params);
            $bindParamsRef = [];
            foreach($bindParams as $key => $value) {
                $bindParamsRef[$key] = &$bindParams[$key];
            }
            call_user_func_array([$stmt, 'bind_param'], $bindParamsRef);
        }
        
        // Kör frågan
        if (!$stmt->execute()) {
            $this->logError("Fel vid körning av fråga: " . $stmt->error . " för frågan: " . $query);
            return false;
        }
        
        return $stmt;
    }
    
    /**
     * Hämta en enda rad från databasen
     * 
     * @param string $query SQL-fråga med platshållare
     * @param array $params Parametrar för frågan
     * @return array|false Raden som en associativ array eller false vid fel
     */
    public function getRow($query, $params = []) {
        $stmt = $this->prepareAndExecute($query, $params);
        
        if (!$stmt) {
            return false;
        }
        
        $result = $stmt->get_result();
        $row = $result->fetch_assoc();
        
        $stmt->close();
        
        return $row;
    }
    
    /**
     * Hämta flera rader från databasen
     * 
     * @param string $query SQL-fråga med platshållare
     * @param array $params Parametrar för frågan
     * @return array|false Raderna som associativa arrayer eller false vid fel
     */
    public function getRows($query, $params = []) {
        $stmt = $this->prepareAndExecute($query, $params);
        
        if (!$stmt) {
            return false;
        }
        
        $result = $stmt->get_result();
        $rows = [];
        
        while ($row = $result->fetch_assoc()) {
            $rows[] = $row;
        }
        
        $stmt->close();
        
        return $rows;
    }
    
    /**
     * Utför en fråga som påverkar data (INSERT, UPDATE, DELETE)
     * 
     * @param string $query SQL-fråga med platshållare
     * @param array $params Parametrar för frågan
     * @return int|false Antal påverkade rader eller false vid fel
     */
    public function execute($query, $params = []) {
        $stmt = $this->prepareAndExecute($query, $params);
        
        if (!$stmt) {
            return false;
        }
        
        $affectedRows = $stmt->affected_rows;
        $stmt->close();
        
        return $affectedRows;
    }
    
    /**
     * Hämta ID för senast insatta raden
     * 
     * @return int Det senaste insatta ID
     */
    public function getLastInsertId() {
        return $this->connection->insert_id;
    }
    
    /**
     * Utför en transaktion med flera SQL-frågor
     * 
     * @param array $queries Array med SQL-frågor och parametrar
     * @return bool Sant om transaktionen lyckades
     */
    public function transaction($queries) {
        // Starta transaktionen
        $this->connection->begin_transaction();
        
        try {
            foreach ($queries as $query) {
                $sql = $query['query'];
                $params = $query['params'] ?? [];
                
                $stmt = $this->prepareAndExecute($sql, $params);
                
                if (!$stmt) {
                    throw new Exception("Transaktionsfel: Kunde inte utföra fråga");
                }
                
                $stmt->close();
            }
            
            // Om allt gick bra, bekräfta ändringarna
            $this->connection->commit();
            return true;
        } catch (Exception $e) {
            // Om något gick fel, ångra alla ändringar
            $this->connection->rollback();
            $this->logError("Transaktionsfel: " . $e->getMessage());
            return false;
        }
    }
    
    /**
     * Escape en sträng för att förhindra SQL-injektion
     * 
     * @param string $string Strängen att escapa
     * @return string Den escapade strängen
     */
    public function escapeString($string) {
        return $this->connection->real_escape_string($string);
    }
    
    /**
     * Kör en direkt SQL-fråga (används med försiktighet)
     * 
     * @param string $query SQL-fråga att köra
     * @return mixed|false Resultat av frågan eller false vid fel
     */
    public function query($query) {
        $result = $this->connection->query($query);
        
        if (!$result) {
            $this->logError("Fel vid körning av direkt fråga: " . $this->connection->error . " för frågan: " . $query);
            return false;
        }
        
        return $result;
    }
    
    /**
     * Logga ett databasfel
     * 
     * @param string $message Felmeddelandet
     */
    private function logError($message) {
        // Logga till fil
        error_log(date("[Y-m-d H:i:s]") . " - DATABASE ERROR: " . $message . "\n", 3, realpath(dirname(__FILE__) . '/../../logs/database_errors.log'));
    }
    
    /**
     * Stäng databasanslutningen (kallas automatiskt vid skriptets slut)
     */
    public function __destruct() {
        if ($this->connection) {
            $this->connection->close();
        }
    }
    
    /**
     * Hindra klonade objekt (del av Singleton-mönstret)
     */
    private function __clone() {}
}