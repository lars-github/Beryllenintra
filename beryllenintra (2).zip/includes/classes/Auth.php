<?php
/**
 * Auth Class
 * 
 * Klass för att hantera användarautentisering och behörighetskontroll
 */
class Auth {
    // Privata egenskaper
    private $db;
    private $loggedIn = false;
    private $userId = null;
    private $userRole = null;
    private $userData = null;
    
    /**
     * Konstruktor
     */
    public function __construct() {
        // Starta sessionen om den inte redan är startad
        if (session_status() == PHP_SESSION_NONE) {
            session_start();
        }
        
        // Hämta databasinstans
        $this->db = Database::getInstance();
        
        // Kontrollera om användaren är inloggad
        $this->checkLogin();
    }
    
    /**
     * Kontrollera om användaren är inloggad
     */
    private function checkLogin() {
        if (isset($_SESSION['user_id'])) {
            // Användaridentitet finns i sessionen
            $this->userId = $_SESSION['user_id'];
            
            // Kontrollera om sessionen har timeout
            if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity'] > SESSION_TIMEOUT)) {
                // Sessionen har förfallit
                $this->logout();
                return;
            }
            
            // Hämta användardata från databasen
            $user = $this->db->getRow("SELECT user_id, username, email, first_name, last_name, role, status, apartment_id FROM users WHERE user_id = ?", [$this->userId]);
            
            if ($user && $user['status'] === 'active') {
                $this->loggedIn = true;
                $this->userRole = $user['role'];
                $this->userData = $user;
                
                // Kontrollera om användaren fortfarande är medlem (äger en lägenhet)
                if ($this->userRole !== 'superadmin' && $this->userRole !== 'admin') {
                    $this->validateMembership();
                }
                
                // Uppdatera aktivitetstiden
                $_SESSION['last_activity'] = time();
            } else {
                // Användaren hittades inte eller är inaktiverad
                $this->logout();
            }
        }
    }
    
    /**
     * Validera att användaren fortfarande är medlem
     */
    private function validateMembership() {
        if ($this->userRole === 'member') {
            $hasMembership = $this->db->getRow(
                "SELECT oh.ownership_id 
                FROM ownership_history oh 
                WHERE oh.user_id = ? 
                AND oh.end_date IS NULL 
                LIMIT 1",
                [$this->userId]
            );
            
            if (!$hasMembership) {
                // Användaren äger inte längre en lägenhet
                $this->db->execute("UPDATE users SET status = 'inactive' WHERE user_id = ?", [$this->userId]);
                $this->logout();
            }
        }
    }
    
    /**
     * Försök att logga in en användare
     * 
     * @param string $username Användarnamn eller e-post
     * @param string $password Lösenord
     * @return bool Lyckad inloggning eller inte
     */
    public function login($username, $password) {
        // Hämta användardata från databasen
        $user = $this->db->getRow("SELECT user_id, password, role, status FROM users WHERE username = ? OR email = ?", [$username, $username]);
        
        if (!$user) {
            // Användaren hittades inte
            return false;
        }
        
        if ($user['status'] !== 'active') {
            // Användaren är inte aktiv
            return false;
        }
        
        // Kontrollera lösenord
        if (password_verify($password, $user['password'])) {
            // Inloggning lyckades
            $_SESSION['user_id'] = $user['user_id'];
            $_SESSION['last_activity'] = time();
            
            // Uppdatera senaste inloggningstid i databasen
            $this->db->execute("UPDATE users SET last_login = NOW() WHERE user_id = ?", [$user['user_id']]);
            
            // Logga aktiviteten
            $this->logActivity($user['user_id'], 'login', 'user', $user['user_id'], 'Användaren loggade in');
            
            // Omladda användardata
            $this->checkLogin();
            
            return true;
        }
        
        return false;
    }
    
    /**
     * Logga ut användaren
     */
    public function logout() {
        // Logga aktiviteten om användaren var inloggad
        if ($this->loggedIn) {
            $this->logActivity($this->userId, 'logout', 'user', $this->userId, 'Användaren loggade ut');
        }
        
        // Rensa sessionsdata
        session_unset();
        session_destroy();
        
        // Nollställ instansvariabler
        $this->loggedIn = false;
        $this->userId = null;
        $this->userRole = null;
        $this->userData = null;
    }
    
    /**
     * Kontrollera om användaren är inloggad
     * 
     * @return bool Om användaren är inloggad eller inte
     */
    public function isLoggedIn() {
        return $this->loggedIn;
    }
    
    /**
     * Kontrollera om användaren har en viss roll
     * 
     * @param string|array $roles En eller flera roller att kontrollera
     * @return bool Om användaren har någon av de angivna rollerna
     */
    public function hasRole($roles) {
        if (!$this->loggedIn) {
            return false;
        }
        
        // Konvertera till array om det är en sträng
        if (!is_array($roles)) {
            $roles = [$roles];
        }
        
        // Superadmin har alla rättigheter
        if ($this->userRole === 'superadmin') {
            return true;
        }
        
        // Admin har medlemsrättigheter
        if ($this->userRole === 'admin' && in_array('member', $roles)) {
            return true;
        }
        
        return in_array($this->userRole, $roles);
    }
    
    /**
     * Kontrollera om användaren har behörighet att se en sida
     * 
     * @param string $visibility Synlighetsnivå för innehållet
     * @return bool Om användaren har behörighet
     */
    public function canAccess($visibility) {
        switch ($visibility) {
            case 'public':
                return true;
            case 'member':
                return $this->loggedIn && ($this->userRole === 'member' || $this->userRole === 'admin' || $this->userRole === 'superadmin');
            case 'admin':
                return $this->loggedIn && ($this->userRole === 'admin' || $this->userRole === 'superadmin');
            case 'superadmin':
                return $this->loggedIn && $this->userRole === 'superadmin';
            default:
                return false;
        }
    }
    
    /**
     * Hämta inloggad användares ID
     * 
     * @return int|null Användar-ID eller null om inte inloggad
     */
    public function getUserId() {
        return $this->userId;
    }
    
    /**
     * Hämta inloggad användares roll
     * 
     * @return string|null Användarroll eller null om inte inloggad
     */
    public function getUserRole() {
        return $this->userRole;
    }
    
    /**
     * Hämta inloggad användares data
     * 
     * @return array|null Användardata eller null om inte inloggad
     */
    public function getUserData() {
        return $this->userData;
    }
    
    /**
     * Kryptera ett lösenord
     * 
     * @param string $password Lösenordet som ska krypteras
     * @return string Krypterat lösenord
     */
    public static function hashPassword($password) {
        return password_hash($password, PASSWORD_DEFAULT);
    }
    
    /**
     * Logga en användaraktivitet
     * 
     * @param int $userId Användar-ID
     * @param string $action Aktivitetstyp
     * @param string $entityType Typ av entitet
     * @param int $entityId ID för den berörda entiteten
     * @param string $description Beskrivning av aktiviteten
     */
    public function logActivity($userId, $action, $entityType, $entityId, $description = '') {
        $ipAddress = $_SERVER['REMOTE_ADDR'] ?? '';
        
        $this->db->execute(
            "INSERT INTO activity_logs (user_id, action, entity_type, entity_id, description, ip_address) 
            VALUES (?, ?, ?, ?, ?, ?)",
            [$userId, $action, $entityType, $entityId, $description, $ipAddress]
        );
    }
    
    /**
     * Kontrollera om en e-postadress eller användarnamn redan används
     * 
     * @param string $email E-postadress
     * @param string $username Användarnamn
     * @return array Resultat med eventuella felmeddelanden
     */
    public function checkUserExists($email, $username) {
        $result = [
            'email_exists' => false,
            'username_exists' => false
        ];
        
        // Kontrollera e-post
        $emailCheck = $this->db->getRow("SELECT user_id FROM users WHERE email = ?", [$email]);
        if ($emailCheck) {
            $result['email_exists'] = true;
        }
        
        // Kontrollera användarnamn
        $usernameCheck = $this->db->getRow("SELECT user_id FROM users WHERE username = ?", [$username]);
        if ($usernameCheck) {
            $result['username_exists'] = true;
        }
        
        return $result;
    }
    
    /**
     * Skicka återställningsmail för lösenord
     * 
     * @param string $email E-postadressen att skicka till
     * @return bool Om mailet skickades framgångsrikt
     */
    public function sendPasswordResetEmail($email) {
        // Kontrollera om användaren finns
        $user = $this->db->getRow("SELECT user_id, first_name, last_name FROM users WHERE email = ? AND status = 'active'", [$email]);
        
        if (!$user) {
            return false;
        }
        
        // Generera en token
        $token = bin2hex(random_bytes(32));
        $expires = date('Y-m-d H:i:s', strtotime('+1 hour'));
        
        // Spara token i databasen
        $this->db->execute(
            "INSERT INTO password_resets (user_id, token, expires) VALUES (?, ?, ?)",
            [$user['user_id'], $token, $expires]
        );
        
        // Skapa återställningslänk
        $resetLink = SITE_URL . '/reset-password.php?token=' . $token;
        
        // Skapa e-postinnehåll
        $subject = 'Återställ ditt lösenord - Brf Beryllen';
        $message = "Hej {$user['first_name']} {$user['last_name']},\n\n";
        $message .= "Du har begärt att återställa ditt lösenord på Brf Beryllens intranät.\n\n";
        $message .= "Klicka på länken nedan för att återställa ditt lösenord:\n";
        $message .= $resetLink . "\n\n";
        $message .= "Länken är giltig i 1 timme.\n\n";
        $message .= "Om du inte har begärt att återställa ditt lösenord kan du ignorera detta mail.\n\n";
        $message .= "Med vänliga hälsningar,\nBrf Beryllen";
        
        $headers = 'From: noreply@brfberyllen.se' . "\r\n" .
                   'Reply-To: noreply@brfberyllen.se' . "\r\n" .
                   'X-Mailer: PHP/' . phpversion();
        
        // Skicka mailet
        return mail($email, $subject, $message, $headers);
    }
}