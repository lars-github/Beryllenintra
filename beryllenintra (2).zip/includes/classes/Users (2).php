<?php
/**
 * User-hantering för BRF Beryllen
 */

class UserManager {
    
    /**
     * Hämtar en användare baserat på ID
     */
    public function getUser($userId) {
        global $db;
        
        $sql = "SELECT u.*, a.LantmNR, a.BrfNR, a.uppg, a.floor, a.area
                FROM users u
                LEFT JOIN apartments a ON u.apartment_id = a.BrfNR
                WHERE u.user_id = " . (int)$userId;
        
        return $db->getRow($sql);
    }
    
    /**
     * Hämtar användare med filtrering på status och roll
     */
    public function getUsers($statusFilter = null, $roleFilter = null) {
        global $db;
        
        $sql = "SELECT u.*, a.LantmNR, a.BrfNR 
                FROM users u
                LEFT JOIN apartments a ON u.apartment_id = a.BrfNR";
        
        $where = [];
        
        if (!empty($statusFilter)) {
            $where[] = "u.status = '" . addslashes($statusFilter) . "'";
        }
        
        if (!empty($roleFilter)) {
            $where[] = "u.role = '" . addslashes($roleFilter) . "'";
        }
        
        if (!empty($where)) {
            $sql .= " WHERE " . implode(" AND ", $where);
        }
        
        $sql .= " ORDER BY u.last_name, u.first_name";
        
        return $db->getRows($sql);
    }
    
    /**
     * Uppdaterar en användares information
     */
    public function updateUser($userId, $data) {
        global $db;
        
        $result = ['success' => false, 'message' => ''];
        
        // Bygg SQL-frågan
        $fields = [];
        
        if (isset($data['first_name'])) {
            $fields[] = "first_name = '" . addslashes($data['first_name']) . "'";
        }
        
        if (isset($data['last_name'])) {
            $fields[] = "last_name = '" . addslashes($data['last_name']) . "'";
        }
        
        if (isset($data['email'])) {
            $fields[] = "email = '" . addslashes($data['email']) . "'";
        }
        
        if (isset($data['phone'])) {
            $fields[] = "phone = '" . addslashes($data['phone']) . "'";
        }
        
        if (isset($data['username'])) {
            $fields[] = "username = '" . addslashes($data['username']) . "'";
        }
        
        if (isset($data['password'])) {
            $hashedPassword = password_hash($data['password'], PASSWORD_DEFAULT);
            $fields[] = "password = '" . addslashes($hashedPassword) . "'";
        }
        
        if (isset($data['status'])) {
            $fields[] = "status = '" . addslashes($data['status']) . "'";
        }
        
        if (isset($data['role'])) {
            $fields[] = "role = '" . addslashes($data['role']) . "'";
        }
        
        if (empty($fields)) {
            $result['success'] = true;
            $result['message'] = 'Inget ändrades.';
            return $result;
        }
        
        $sql = "UPDATE users SET " . implode(", ", $fields) . " WHERE user_id = " . (int)$userId;
        
        $success = $db->query($sql);
        
        if ($success) {
            $result['success'] = true;
            $result['message'] = 'Användaruppgifter uppdaterade.';
        } else {
            $result['message'] = 'Ett fel uppstod vid uppdatering.';
        }
        
        return $result;
    }
    
    /**
     * Tar bort en användare
     */
    public function deleteUser($userId) {
        global $db;
        
        $sql = "DELETE FROM users WHERE user_id = " . (int)$userId;
        return $db->query($sql);
    }
    
    /**
     * Lägger till ägarskap för en lägenhet
     */
    public function addOwnership($userId, $apartmentId, $sharePercentage, $startDate) {
        global $db;
        
        $sql = "INSERT INTO ownership_history (user_id, apartment_id, share_percentage, start_date, created_by) 
               VALUES (" . (int)$userId . ", " . (int)$apartmentId . ", " . (float)$sharePercentage . ", '" . $startDate . "', " . (int)($_SESSION['user_id'] ?? 0) . ")";
        
        return $db->query($sql);
    }
    
    /**
     * Avslutar ägarskap för en lägenhet
     */
    public function endOwnership($userId, $apartmentId, $endDate) {
        global $db;
        
        $sql = "UPDATE ownership_history 
               SET end_date = '" . $endDate . "', 
                   updated_at = NOW() 
               WHERE user_id = " . (int)$userId . " 
               AND apartment_id = " . (int)$apartmentId . " 
               AND end_date IS NULL";
        
        return $db->query($sql);
    }
}
?>