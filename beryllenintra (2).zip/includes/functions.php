<?php
/**
 * Hjälpfunktioner för BRF Beryllen's intranät
 * 
 * Denna fil innehåller allmänna hjälpfunktioner som används 
 * i hela systemet. Funktionerna är globalt tillgängliga.
 */

// Förhindra direkt åtkomst till denna fil
if (!defined('ACCESS_ALLOWED')) {
    header('HTTP/1.0 403 Forbidden');
    exit;
}

/**
 * Skriver ut data i ett läsbart format för felsökning
 * 
 * @param mixed $data Data att skriva ut
 * @param bool $die Om skriptet ska avslutas efter utskrift
 * @return void
 */
function debug($data, $die = false) {
    echo '<pre>';
    print_r($data);
    echo '</pre>';
    
    if ($die) {
        die();
    }
}

/**
 * Omdirigerar användaren till en annan sida
 * 
 * @param string $url URL att omdirigera till
 * @return void
 */
function redirect($url) {
    header("Location: $url");
    exit;
}

/**
 * Skapar en säker URL-vänlig sträng (slug)
 * 
 * @param string $string Strängen att konvertera
 * @return string Den konverterade strängen
 */
function createSlug($string) {
    // Konvertera specialtecken
    $string = mb_strtolower($string, 'UTF-8');
    $string = str_replace(['å', 'ä', 'ö', 'Å', 'Ä', 'Ö'], ['a', 'a', 'o', 'a', 'a', 'o'], $string);
    
    // Ta bort specialtecken och ersätt mellanslag med bindestreck
    $string = preg_replace('/[^a-z0-9\s-]/', '', $string);
    $string = preg_replace('/[\s-]+/', '-', $string);
    $string = trim($string, '-');
    
    return $string;
}

/**
 * Filtrerar och validerar data
 * 
 * @param string $data Data att filtrera
 * @param string $type Typ av filtrering
 * @return mixed Den filtrerade datan
 */
function filterInput($data, $type = 'string') {
    // Trimma bort blanksteg
    $data = trim($data);
    
    // Filtrera baserat på typ
    switch ($type) {
        case 'email':
            $data = filter_var($data, FILTER_SANITIZE_EMAIL);
            break;
        case 'url':
            $data = filter_var($data, FILTER_SANITIZE_URL);
            break;
        case 'int':
            $data = filter_var($data, FILTER_SANITIZE_NUMBER_INT);
            break;
        case 'float':
            $data = filter_var($data, FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION);
            break;
        case 'html':
            // Tillåt viss HTML men ta bort skadlig kod
            $data = htmlspecialchars($data, ENT_QUOTES, 'UTF-8');
            break;
        case 'string':
        default:
            // Ta bort HTML och PHP-taggar
            $data = strip_tags($data);
            // Förhindra XSS-attacker
            $data = htmlspecialchars($data, ENT_QUOTES, 'UTF-8');
            break;
    }
    
    return $data;
}

/**
 * Validerar ett personnummer/samordningsnummer
 * 
 * @param string $pnr Personnumret att validera
 * @return bool Sant om personnumret är giltigt
 */
function validatePersonalNumber($pnr) {
    // Ta bort bindestreck och mellanslag
    $pnr = str_replace(['-', ' '], '', $pnr);
    
    // Kontrollera att det är 10 eller 12 siffror
    if (!preg_match('/^[0-9]{10}$|^[0-9]{12}$/', $pnr)) {
        return false;
    }
    
    // Om 12 siffror, ta de sista 10
    if (strlen($pnr) == 12) {
        $pnr = substr($pnr, 2);
    }
    
    // Extrahera datum och kontrollera giltighet
    $year = substr($pnr, 0, 2);
    $month = substr($pnr, 2, 2);
    $day = substr($pnr, 4, 2);
    
    // Kontrollera månad och dag
    if ($month < 1 || $month > 12 || $day < 1 || $day > 31) {
        return false;
    }
    
    // Kontrollsiffra-validering (Luhn-algoritmen)
    $controlNumber = substr($pnr, -1);
    $digits = substr($pnr, 0, 9);
    $sum = 0;
    
    for ($i = 0; $i < 9; $i++) {
        $val = intval($digits[$i]);
        $val = $i % 2 == 0 ? $val * 2 : $val;
        if ($val > 9) {
            $val -= 9;
        }
        $sum += $val;
    }
    
    $checksum = (10 - ($sum % 10)) % 10;
    
    return $checksum == $controlNumber;
}

/**
 * Formaterar ett datum till svensk format
 * 
 * @param string $date Datum att formatera
 * @param string $format Önskat format
 * @return string Det formaterade datumet
 */
function formatDate($date, $format = 'Y-m-d') {
    $timestamp = strtotime($date);
    return date($format, $timestamp);
}

/**
 * Genererar en slumpmässig sträng
 * 
 * @param int $length Längden på strängen
 * @return string Den genererade strängen
 */
function generateRandomString($length = 10) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $randomString = '';
    
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, strlen($characters) - 1)];
    }
    
    return $randomString;
}

/**
 * Kontrollerar om en sträng innehåller svenska tecken
 * 
 * @param string $string Strängen att kontrollera
 * @return bool Sant om strängen innehåller svenska tecken
 */
function hasSwedishChars($string) {
    return preg_match('/[åäöÅÄÖ]/', $string);
}

/**
 * Formaterar ett mobilnummer till ett konsekvent format
 * 
 * @param string $phone Mobilnumret att formatera
 * @return string Det formaterade mobilnumret
 */
function formatPhoneNumber($phone) {
    // Ta bort alla icke-numeriska tecken
    $phone = preg_replace('/[^0-9]/', '', $phone);
    
    // Om det börjar med 0, lägg till +46 och ta bort första nollan
    if (substr($phone, 0, 1) == '0') {
        $phone = '46' . substr($phone, 1);
    }
    
    // Lägg till plustecken i början om det börjar med landet kod
    if (substr($phone, 0, 2) == '46') {
        $phone = '+' . $phone;
    }
    
    return $phone;
}

/**
 * Kontrollerar om ett givet värde finns i en array av objekt
 * 
 * @param array $array Array att söka i
 * @param string $key Nyckeln att söka efter
 * @param mixed $value Värdet att hitta
 * @return bool Sant om värdet hittades
 */
function inArrayObject($array, $key, $value) {
    foreach ($array as $item) {
        if (is_object($item) && isset($item->$key) && $item->$key == $value) {
            return true;
        } elseif (is_array($item) && isset($item[$key]) && $item[$key] == $value) {
            return true;
        }
    }
    return false;
}

/**
 * Konverterar en filstorlek till läsbart format
 * 
 * @param int $bytes Filstorlek i bytes
 * @param int $precision Antal decimaler
 * @return string Formaterad filstorlek
 */
function formatFileSize($bytes, $precision = 2) {
    $units = ['B', 'KB', 'MB', 'GB', 'TB'];
    $bytes = max($bytes, 0);
    $pow = floor(($bytes ? log($bytes) : 0) / log(1024));
    $pow = min($pow, count($units) - 1);
    $bytes /= pow(1024, $pow);
    
    return round($bytes, $precision) . ' ' . $units[$pow];
}

/**
 * Kontrollerar om en sträng är ett giltigt JSON
 * 
 * @param string $string Strängen att kontrollera
 * @return bool Sant om strängen är giltig JSON
 */
function isValidJson($string) {
    json_decode($string);
    return json_last_error() === JSON_ERROR_NONE;
}

/**
 * Trunkar en textsträng till en viss längd och lägger till "..." om trunkerad
 * 
 * @param string $string Textsträngen att trunka
 * @param int $length Maximal längd
 * @param string $append Text att lägga till vid trunkering
 * @return string Den trunkerade strängen
 */
function truncateString($string, $length = 100, $append = '...') {
    if (strlen($string) > $length) {
        $string = substr($string, 0, $length);
        $string = rtrim($string);
        $string .= $append;
    }
    
    return $string;
}