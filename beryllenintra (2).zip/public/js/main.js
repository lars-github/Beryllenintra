/**
 * Huvudsaklig JavaScript för BRF Beryllens intranät
 */

// Initiera när DOM är laddad
document.addEventListener('DOMContentLoaded', function() {
    // Aktivera Bootstrap tooltips
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
    
    // Aktivera Bootstrap popovers
    var popoverTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="popover"]'));
    var popoverList = popoverTriggerList.map(function (popoverTriggerEl) {
        return new bootstrap.Popover(popoverTriggerEl);
    });
    
    // Auto-stäng alerts efter 5 sekunder
    var alertList = document.querySelectorAll('.alert:not(.alert-permanent)');
    alertList.forEach(function(alert) {
        setTimeout(function() {
            var bsAlert = new bootstrap.Alert(alert);
            bsAlert.close();
        }, 5000);
    });
    
    // Bekräfta radering
    var deleteButtons = document.querySelectorAll('.btn-delete, [data-confirm]');
    deleteButtons.forEach(function(button) {
        button.addEventListener('click', function(event) {
            var message = this.getAttribute('data-confirm') || 'Är du säker på att du vill radera detta?';
            if (!confirm(message)) {
                event.preventDefault();
                return false;
            }
        });
    });
    
    // Datumväljare för formulär
    var dateInputs = document.querySelectorAll('.date-picker');
    dateInputs.forEach(function(input) {
        input.addEventListener('focus', function() {
            this.type = 'date';
        });
        
        input.addEventListener('blur', function() {
            if (!this.value) {
                this.type = 'text';
            }
        });
    });
    
    // Hantera tab-funktionalitet i textareas
    var textareas = document.querySelectorAll('textarea.tab-enabled');
    textareas.forEach(function(textarea) {
        textarea.addEventListener('keydown', function(e) {
            if (e.key === 'Tab') {
                e.preventDefault();
                var start = this.selectionStart;
                var end = this.selectionEnd;
                
                this.value = this.value.substring(0, start) + "\t" + this.value.substring(end);
                this.selectionStart = this.selectionEnd = start + 1;
            }
        });
    });
    
    // Hantera sökning och filtrering i tabeller
    var tableFilters = document.querySelectorAll('.table-filter');
    tableFilters.forEach(function(filter) {
        filter.addEventListener('input', function() {
            var tableId = this.getAttribute('data-table');
            var table = document.getElementById(tableId);
            
            if (!table) return;
            
            var rows = table.querySelectorAll('tbody tr');
            var searchText = this.value.toLowerCase();
            
            rows.forEach(function(row) {
                var text = row.textContent.toLowerCase();
                var display = text.indexOf(searchText) > -1 ? '' : 'none';
                row.style.display = display;
            });
        });
    });
    
    // Hantera sortering av tabeller
    var tableSorters = document.querySelectorAll('.table-sort');
    tableSorters.forEach(function(sorter) {
        sorter.addEventListener('click', function() {
            var tableId = this.closest('table').id;
            var columnIndex = this.cellIndex;
            var sortDirection = this.getAttribute('data-sort') === 'asc' ? 'desc' : 'asc';
            
            // Uppdatera data-sort attributet
            this.setAttribute('data-sort', sortDirection);
            
            // Uppdatera sorteringsikonen
            var sortIcons = this.closest('tr').querySelectorAll('.sort-icon');
            sortIcons.forEach(function(icon) {
                icon.innerHTML = '';
            });
            
            var icon = this.querySelector('.sort-icon');
            if (icon) {
                icon.innerHTML = sortDirection === 'asc' ? '&#9650;' : '&#9660;';
            }
            
            // Sortera tabellen
            sortTable(tableId, columnIndex, sortDirection);
        });
    });
    
    // Funktion för att sortera tabeller
    function sortTable(tableId, columnIndex, sortDirection) {
        var table = document.getElementById(tableId);
        if (!table) return;
        
        var rows = Array.from(table.querySelectorAll('tbody tr'));
        var sortMultiplier = sortDirection === 'asc' ? 1 : -1;
        
        rows.sort(function(a, b) {
            var cellA = a.cells[columnIndex].textContent.trim().toLowerCase();
            var cellB = b.cells[columnIndex].textContent.trim().toLowerCase();
            
            // Kontrollera om det är ett datum
            if (isDate(cellA) && isDate(cellB)) {
                return (new Date(cellA) - new Date(cellB)) * sortMultiplier;
            }
            
            // Kontrollera om det är ett nummer
            if (!isNaN(cellA) && !isNaN(cellB)) {
                return (parseFloat(cellA) - parseFloat(cellB)) * sortMultiplier;
            }
            
            // Annars sortera som text
            return cellA.localeCompare(cellB, 'sv') * sortMultiplier;
        });
        
        // Uppdatera tabellen
        var tbody = table.querySelector('tbody');
        rows.forEach(function(row) {
            tbody.appendChild(row);
        });
    }
    
    // Hjälpfunktion för att kontrollera om en sträng är ett datum
    function isDate(dateStr) {
        var datePattern = /^(\d{4}-\d{2}-\d{2}|\d{2}-\d{2}-\d{4}|\d{2}\/\d{2}\/\d{4}|\d{2}\.\d{2}\.\d{4})$/;
        return datePattern.test(dateStr);
    }
    
    // Dynamisk sökning i formulär
    var dynamicSearches = document.querySelectorAll('.dynamic-search');
    dynamicSearches.forEach(function(search) {
        search.addEventListener('input', function() {
            var target = this.getAttribute('data-target');
            var minLength = parseInt(this.getAttribute('data-min-length') || '2');
            var searchText = this.value.trim();
            
            if (searchText.length < minLength) {
                document.getElementById(target).innerHTML = '';
                return;
            }
            
            // Här kan du implementera AJAX-anrop för sökning
            // Detta är bara en plats där du kan lägga till sådan funktionalitet
            console.log('Söker efter:', searchText);
        });
    });
});