<?php
/**
 * Utloggningssida för BRF Beryllen
 * 
 * Denna sida loggar ut användaren och omdirigerar till startsidan
 */

// Initiera systemet
require_once('init.php');

// Logga ut användaren
$auth->logout();

// Sätt ett meddelande
$_SESSION['flash_message'] = 'Du har loggats ut.';
$_SESSION['flash_type'] = 'info';

// Omdirigera till startsidan
redirect(SITE_URL);