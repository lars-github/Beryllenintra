<?php
/**
 * Databasanslutningskonfiguration
 * 
 * Denna fil innehåller inställningar för anslutning till databasen.
 * Filen inkluderas i Database-klassen.
 */

// Databasanslutningsparametrar
define('DB_HOST', 'bilder.vip.mysql.service.one.com');     // Databasserver
define('DB_USER', 'bilder_vipberyllenintra');  // Databasanvändare
define('DB_PASS', 'claude');      // Databaslösenord
define('DB_NAME', 'bilder_vipberyllenintra');  // Databasnamn
define('DB_CHARSET', 'utf8mb4');    // Teckenkodning

// För att förhindra direkt åtkomst till denna fil
if (!defined('ACCESS_ALLOWED')) {
    header('HTTP/1.0 403 Forbidden');
    exit;
}
?>