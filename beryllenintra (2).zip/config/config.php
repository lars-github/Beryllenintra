<?php
/**
 * Huvudkonfiguration
 * 
 * Denna fil innehåller grundläggande inställningar för hela systemet.
 * Filen inkluderas i början av varje sida.
 */

// Förhindra direkt åtkomst
if (!defined('ACCESS_ALLOWED')) {
    header('HTTP/1.0 403 Forbidden');
    exit;
}

// Definiera basväg till projektet
define('BASE_PATH', realpath(dirname(__FILE__) . '/..'));

// URL till sajten (anpassa efter din domän)
define('SITE_URL', 'https://www.bilder.vip/beryllenintra');

// Webbplatsens titel
define('SITE_TITLE', 'Brf Exemplet - Intranät');

// Säkerhetsinställningar
define('SESSION_TIMEOUT', 1800); // 30 minuter i sekunder

// Inställningar för behörighetsnivåer
define('ROLE_PUBLIC', 'public');
define('ROLE_MEMBER', 'member');
define('ROLE_ADMIN', 'admin');
define('ROLE_SUPERADMIN', 'superadmin');

// Felrapportering
error_reporting(E_ALL);
ini_set('display_errors', 0); // Sätt till 1 under utveckling, 0 i produktion
ini_set('log_errors', 1);
ini_set('error_log', BASE_PATH . '/logs/error.log');

// Tidszon
date_default_timezone_set('Europe/Stockholm');

// Sessionshantering
ini_set('session.cookie_httponly', 1);
ini_set('session.use_only_cookies', 1);
ini_set('session.cookie_secure', 0); // Sätt till 1 om du använder HTTPS

// Inkludera databasanslutning
define('ACCESS_ALLOWED', true);
require_once(BASE_PATH . '/config/database.php');
?>